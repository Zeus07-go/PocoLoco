// Pure game rules (no rendering). World 0 = Reality, world 1 = Mirror.
// Maps are "as displayed", so the Mirror figure's column is C-1-pc.
// Tile legend:  . floor   W wall   # gap   X pushable crate (on floor)
//   a b  pressure plates   -> open the matching gate (A B) in the OTHER world
//   A B  gates             -> open while the matching plate in the other world is occupied
//   k l  keys              -> picking one up unlocks the matching door (K L) in the OTHER world
//   K L  locked doors
import {C,R,SC,SR,EC,ER} from './levels.js';

const KEYS='kl',GATES='AB',DOORS='KL';
export const inb=(c,r)=>c>=0&&c<C&&r>=0&&r<R;

export function parseLevel(lv){
  const maps=[],crates=[[],[]],at=[{},{}];
  [lv.R,lv.M].forEach((rows,w)=>{
    maps[w]=rows.map((row,r)=>[...row].map((ch,c)=>{
      if(ch==='X'){crates[w].push([c,r]);return '.'}
      (at[w][ch]=at[w][ch]||[]).push([c,r]);return ch}));
  });
  return {maps,crates,at};
}
export const initState=P=>({pc:SC,pr:SR,cr:P.crates.map(a=>a.map(p=>[...p])),got:[]});
export const cloneState=s=>({pc:s.pc,pr:s.pr,cr:s.cr.map(a=>a.map(p=>[...p])),got:[...s.got]});
export const figures=s=>[[s.pc,s.pr],[C-1-s.pc,s.pr]];

// Is a figure or crate standing on this cell of world w?
export function occupied(s,w,c,r){
  const f=figures(s)[w];
  return (f[0]===c&&f[1]===r)||s.cr[w].some(q=>q[0]===c&&q[1]===r);
}
// Gate X in world w is open while plate x (lowercase) in the other world is occupied.
export function gateOpen(P,s,w,ch){
  return (P.at[1-w][ch.toLowerCase()]||[]).some(([c,r])=>occupied(s,1-w,c,r));
}
// Door X in world w is open once key x was picked up in the other world.
export const doorOpen=(s,w,ch)=>s.got.includes((1-w)+ch.toLowerCase());

const baseSolid=(P,w,c,r)=>!inb(c,r)||P.maps[w][r][c]==='W'||P.maps[w][r][c]==='#';
export function solid(P,s,w,c,r){
  if(baseSolid(P,w,c,r))return true;
  const ch=P.maps[w][r][c];
  if(GATES.includes(ch))return !gateOpen(P,s,w,ch);
  if(DOORS.includes(ch))return !doorOpen(s,w,ch);
  return false;
}

// rdx = horizontal step in Reality (Mirror moves -rdx), dy = vertical step in both.
// Returns the new state, or null if the move is illegal in either world.
export function step(P,s,rdx,dy){
  const n=cloneState(s);n.pc+=rdx;n.pr+=dy;
  const d=[[rdx,dy],[-rdx,dy]],to=figures(n);
  for(let w=0;w<2;w++){
    const [tc,tr]=to[w];
    if(baseSolid(P,w,tc,tr))return null;
    const i=n.cr[w].findIndex(q=>q[0]===tc&&q[1]===tr);
    if(i>=0){ // push one crate; no chains
      const nc=tc+d[w][0],nr=tr+d[w][1];
      if(baseSolid(P,w,nc,nr)||n.cr[w].some(q=>q[0]===nc&&q[1]===nr))return null;
      n.cr[w][i]=[nc,nr];
    }
    const ch=P.maps[w][tr][tc];
    if(KEYS.includes(ch)&&!n.got.includes(w+ch))n.got.push(w+ch);
  }
  // Settled state must be legal: nothing may stand in a closed gate or locked door
  // (this also forbids leaving a plate while something stands in the gate it feeds).
  const f=figures(n);
  for(let w=0;w<2;w++){
    if(solid(P,n,w,f[w][0],f[w][1]))return null;
    for(const q of n.cr[w])if(solid(P,n,w,q[0],q[1]))return null;
  }
  return n;
}
export const won=s=>s.pc===EC&&s.pr===ER;
