# Builds the v3 standalone HTML: original v2 HTML (three.js bundle) + CSS/markup + patched game script.
import sys;d=sys.argv[1] if len(sys.argv)>1 else '.';orig=sys.argv[2] if len(sys.argv)>2 else '/tmp/orig.html'
s=open(orig).read()
def rep(a,b):
    global s;assert s.count(a)==1,a[:50];s=s.replace(a,b)
rep('</style>',open(d+'/source/css_v3.css').read()+'</style>')
rep('<div id="bar"><i></i></div></div>','<div id="bar"><i></i></div><div id="eq"></div></div>')
rep('<button id="b2">Restart</button></div>','<button id="b2">Restart</button><button id="b3">Level Select</button><button id="b4">Main Menu</button></div>')
rep('<button id="bM">☰ Menu</button>','<button id="bM">☰ Menu</button><button class="sb"></button>')
rep('<div class="ov lab" id="lr">','<div class="ov" id="mtop"><div><span class="fig hero"></span><span>You are the sunrise hero.<br>Arrow keys / WASD</span></div><div><span id="mt2"></span><span class="fig echo"></span></div></div>\n<div class="ov lab" id="lr">')
cards=[('MOVE','⇆','Use Arrow Keys or WASD to move the hero.'),('ECHO FOLLOWS','◌','Your echo repeats each move a few steps later.'),('WAIT','•','Press Space to wait a turn. Waiting is recorded, so the echo can catch up.'),('TWO EXITS','◎','Gold exit for you, turquoise exit for your echo. Reach both before moves run out.'),('LITTLE HELPERS','▣','Crates push. Stand anything on a plate to open its gate.'),('MIND THE GAPS','#','Hero and echo both fall into gaps. Plan the echo’s path too.')]
h='<div id="hud2">'+''.join('<div class="card"><div class="ic"><span class="ar" style="font-size:20px">%s</span></div><div class="txt"><h3>%s</h3><p>%s</p></div></div>'%(i,t,p) for t,i,p in cards)+'</div>'
menu='''<div id="menu"><button class="sb"></button><header><h1>ECHOBOUND</h1><p>Two Worlds. One Escape.</p></header><div id="cards">
<article class="cc mi"><canvas id="cvm"></canvas><div class="cb"><small>PHASE 1 · START HERE</small><h2>MIMIC</h2><span class="bd">BEGINNER</span><p>Every step leaves an echo.</p><button id="pm">PLAY MIMIC</button></div></article>
<article class="cc mr"><canvas id="cvr"></canvas><div class="cb"><small>PHASE 2 · A TOUGHER CHALLENGE</small><h2>MIRROR</h2><span class="bd">ADVANCED</span><p>Two worlds. Reversed paths. One escape.</p><button id="pr">PLAY MIRROR</button></div></article>
</div><p class="hint">New here? Begin with MIMIC, then take on MIRROR.</p></div>
<div id="lvsel"><button class="sb"></button><h2 id="lst"></h2><p id="lss"></p><div id="lsg"></div><button id="lsb">← Main Menu</button></div>'''
i=s.index('<script');j=s.rindex('</div></div>',0,i)
s=s[:j]+'</div>'+h+menu+'</div>'+s[j+len('</div></div>'):]
a=s.rindex('((THREE)=>{');b=s.index('</script></body>')
s=s[:a]+open(d+'/source/game_iife.js').read()+s[b:]
open(d+'/ECHOBOUND_Two_Worlds_One_Escape.html','w').write(s);print(len(s))
