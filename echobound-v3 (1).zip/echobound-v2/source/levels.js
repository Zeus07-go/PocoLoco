// Level data. R = Reality map, M = Mirror map (both "as displayed").
//  .  floor      W  wall      #  gap
//  X  pushable crate (pushed in both worlds, mirrored)
//  a b  pressure plates -> open gates A B in the OTHER world while occupied (figure or crate)
//  k l  keys            -> unlock doors K L in the OTHER world once picked up
export const C=7,R=7,SC=1,SR=6,EC=5,ER=0;
export const LV=[
{n:'LEVEL 1',t:'FIRST STEPS',R:['.......','.......','..WW...','.......','.......','.......','.......'],M:['.......','.......','...W...','.......','.......','.......','.......']},
{n:'LEVEL 2',t:'THE REFLECTION',R:['W......','.......','W......','......W','...WW..','.W.W...','......#'],M:['...W...','....#..','.......','#WW....','WW..W..','#....W.','..W##..']},
{n:'LEVEL 3',t:'THE FRACTURE',R:['W.....W','.......','.....W.','.......','.....#.','.W.W...','...WW..'],M:['W.W.W..','..W....','....W.W','....W..','.W.WWW.','W#..WW.','...#W..']},
{n:'LEVEL 4',t:'HEAVY ECHO',R:['....W.#','.......','...W..#','...WW..','...#...','.W.....','X..W...'],M:['.....X.','#...W..','W.....W','..W..WW','..W....','X.W...W','.......']},
{n:'LEVEL 5',t:'SKELETON KEYS',R:['......W','.....W#','..lW..W','.#...W.','...W...','..W..K.','..W#...'],M:['W..L...','W...W..','k..W.W.','...W...','.#.....','W......','....W..']},
{n:'LEVEL 6',t:'THE WEIGHT BETWEEN',R:['....W.#','.....A.','...W..#','...WW..','...#...','.W.....','...W...'],M:['.....W.','#...W..','W.....W','..W..WW','aXW....','.....W.','.......']},
{n:'LEVEL 7',t:'CONVERGENCE',R:['.#.....','.......','..W.#.W','..#...W','...W..W','..WWXkW','W..Wa..'],M:['W..W...','..K....','..W....','.W..W..','.W.W..W','.A....W','......W']}];
