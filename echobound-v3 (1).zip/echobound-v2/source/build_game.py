import re
def rep(s,a,b):
    assert s.count(a)==1,a;return s.replace(a,b)
L=open('levels.js').read()
mx=iter([15,16,22,22,24,32,28])
L=re.sub(r"(\{n:'LEVEL \d',t:'[^']+',)",lambda m:m.group(1)+'mx:%d,'%next(mx),L)
g=open('logic.js').read()
g=rep(g,"export function step(P,s,rdx,dy){","export function step(P,s,rdx,dy,allowGap=false){")
g=rep(g,"    if(baseSolid(P,w,tc,tr))return null;","    const gap=allowGap&&inb(tc,tr)&&P.maps[w][tr][tc]==='#';\n    if(baseSolid(P,w,tc,tr)&&!gap)return null;")
g=rep(g,"    if(solid(P,n,w,f[w][0],f[w][1]))return null;","    if(solid(P,n,w,f[w][0],f[w][1])&&!(allowGap&&P.maps[w][f[w][1]][f[w][0]]==='#'))return null;")
m=open('main.js').read()
m=rep(m,"let L,P,S,hist=[],act=0,li=0,moves=0,state='play',shake=0,W=[];","let L,P,S,hist=[],act=0,li=0,moves=0,state='play',shake=0,W=[],fall=[false,false],ft=0;")
m=rep(m,"function plateMesh(col){const g=new THREE.Group(),top=new THREE.Mesh(new THREE.CylinderGeometry(.3,.3,.05,16),glowM(col,.2));top.position.y=.04;\n g.add(new THREE.Mesh(new THREE.CylinderGeometry(.38,.4,.06,16),std(0x2a2f3a)),top);g.userData.top=top;return g}",
"function plateMesh(col){const g=new THREE.Group(),top=new THREE.Mesh(new THREE.BoxGeometry(.6,.05,.6),glowM(col,.2));top.position.y=.04;\n g.add(new THREE.Mesh(new THREE.BoxGeometry(.78,.06,.78),std(0x2a2f3a)),top);g.userData.top=top;return g}")
head=m[:m.index("function sync(){")]
tail=open('tail.js').read()
strip=lambda s:re.sub(r"^export ","",re.sub(r"^import .*$","",s,flags=re.M),flags=re.M)
ids="b1,b2,bR,bM,bS,bU,ot,os,ov,mv,mxv,info,bar,c,lr,lm,t1,fx,lvn,lvt,stage".split(',')
prelude="const $=id=>document.getElementById(id);const ["+",".join(ids)+"]=["+",".join("'%s'"%i for i in ids)+"].map($);\n"
names="Group:Ie,Mesh:Dt,MeshStandardMaterial:wn,MeshBasicMaterial:vn,BoxGeometry:ge,TorusGeometry:va,OctahedronGeometry:Cm,ConeGeometry:gr,SphereGeometry:Im,CircleGeometry:hl,PlaneGeometry:Xa,PointLight:Pr,Scene:Hs,Fog:Tr,HemisphereLight:Ml,DirectionalLight:Tl,BufferGeometry:It,Points:cl,PointsMaterial:ks,WebGLRenderer:Ut,PerspectiveCamera:ue,Clock:yg,Color:ct,Float32BufferAttribute:Tt,AdditiveBlending:vs"
game="((THREE)=>{\n"+prelude+strip(L)+"\n"+strip(g)+"\n"+strip(head)+strip(tail)+"\n})({"+names+"});\n"
open('game_iife.js','w').write(game);print(len(game))
