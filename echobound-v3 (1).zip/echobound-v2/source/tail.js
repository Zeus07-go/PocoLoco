function sync(){W.forEach((w,i)=>{
 w.crates.forEach((o,j)=>o.userData.t=[S.cr[i][j][0]-3,S.cr[i][j][1]-3]);
 w.plates.forEach(o=>o.m.userData.on=occupied(S,i,o.c,o.r));
 w.gates.forEach(o=>o.m.userData.open=gateOpen(P,S,i,o.ch));
 w.doors.forEach(o=>o.m.userData.open=doorOpen(S,i,o.ch));
 w.keys.forEach(o=>o.m.userData.got=S.got.includes(i+o.ch))})}
function setAct(a){act=a;lr.classList.toggle('act',a==0);lm.classList.toggle('act',a==1);
 t1.innerHTML=a?'You control the Mirror.<br>Reality mirrors you.':'You control Reality.<br>The Mirror mirrors you.'}
const switchWorld=()=>{if(state==='play')setAct(1-act)};
function hud(){const left=L.mx-moves;mv.textContent=moves;mxv.textContent=L.mx;info.classList.toggle('low',left<=3);bar.firstChild.style.width=Math.max(0,left/L.mx*100)+'%'}
function flash(){fx.classList.remove('on');fx.offsetWidth;fx.classList.add('on')}
function load(i){li=i;L=LV[i];P=parseLevel(L);S=initState(P);hist=[];moves=0;state='play';fall=[false,false];ft=0;shake=0;b2.style.display='';
 W=[build(P.maps[0],'r',false),build(P.maps[1],'m',true)];
 W[0].ac.position.set(S.pc-3,0,S.pr-3);W[1].ac.position.set(C-1-S.pc-3,0,S.pr-3);
 sync();setAct(0);lvn.textContent=L.n;lvt.textContent=L.t;hud();ov.classList.remove('on')}
function lose(t,sub){state='lost';ot.textContent=t;os.textContent=sub;b1.textContent='Try Again';b1.onclick=restart;b2.style.display='none';ov.classList.add('on')}
// dx is the direction pressed on the ACTIVE world; Reality's horizontal step is flipped when the Mirror is active.
function move(dx,dy){if(state!=='play')return;const t=step(P,S,act?-dx:dx,dy,true);
 if(!t){shake=.25;return}
 hist.push(S);S=t;moves++;hud();sync();
 const g=figures(S).map((p,w)=>P.maps[w][p[1]][p[0]]==='#');
 if(g[0]||g[1]){state='falling';fall=g;ft=0;shake=.5;flash();return}
 if(won(S)){state='won';setTimeout(win,450)}
 else if(moves>=L.mx){state='lost';shake=.3;setTimeout(()=>lose('OUT OF MOVES','You used all '+L.mx+' moves.'),600)}}
function undo(){if(state!=='play'||!hist.length)return;S=hist.pop();moves--;hud();sync()}
function win(){const last=li==LV.length-1;ot.textContent=last?'ALL WORLDS ESCAPED':'LEVEL COMPLETE';
 os.textContent='Both exits reached in '+moves+' moves.';b2.style.display='';b1.textContent=last?'Play Again':'Next Level';b1.onclick=()=>load(last?0:li+1);ov.classList.add('on')}
function menu(){if(state!=='play'&&state!=='paused')return;if(state==='paused'){resume();return}state='paused';b2.style.display='';ot.textContent='PAUSED';os.textContent=L.n+' — '+L.t;b1.textContent='Resume';b1.onclick=resume;ov.classList.add('on')}
function resume(){state='play';ov.classList.remove('on')}
const restart=()=>load(li);
b2.onclick=restart;bR.onclick=restart;bM.onclick=menu;bS.onclick=switchWorld;bU.onclick=undo;
addEventListener('click',e=>{if(e.target.tagName=='BUTTON')e.target.blur()});
c.addEventListener('pointerdown',e=>{const b=c.getBoundingClientRect();if(state==='play')setAct(e.clientX-b.left<b.width/2?0:1)});
addEventListener('keydown',e=>{const k=e.key.toLowerCase();
 const m={arrowup:[0,-1],w:[0,-1],arrowdown:[0,1],s:[0,1],arrowleft:[-1,0],a:[-1,0],arrowright:[1,0],d:[1,0]}[k];
 if(m){e.preventDefault();move(...m)}else if(k==' '||k=='tab'){e.preventDefault();switchWorld()}else if(k=='z'||k=='u'||k=='backspace'){e.preventDefault();undo()}else if(k=='r')restart();else if(k=='escape'||k=='p')menu()});
const ren=new THREE.WebGLRenderer({canvas:c,antialias:true});ren.shadowMap.enabled=true;ren.setScissorTest(true);
const cam=new THREE.PerspectiveCamera(34,1,.1,100);let cw=1,ch=1;
function size(){cw=stage.clientWidth;ch=stage.clientHeight;ren.setPixelRatio(Math.min(devicePixelRatio,2));ren.setSize(cw,ch,false)}
addEventListener('resize',size);size();load(0);
const clk=new THREE.Clock();
(function loop(){requestAnimationFrame(loop);const dt=Math.min(clk.getDelta(),.05),t=clk.elapsedTime;shake=Math.max(0,shake-dt);
 if(state==='falling'){ft+=dt;if(ft>1.1)lose('YOU FELL','Step into a gap in either world and you are gone.')}
 const hw=Math.floor(cw/2),asp=hw/ch,dist=17*Math.max(1,1/asp*.95);
 cam.aspect=asp;cam.position.set(0,dist*.72,dist*.7);cam.lookAt(0,-.2,.2);cam.updateProjectionMatrix();
 const tg=[[S.pc-3,S.pr-3],[C-1-S.pc-3,S.pr-3]],k=Math.min(1,dt*14);
 W.forEach((w,i)=>{const a=w.ac;a.position.x+=(tg[i][0]-a.position.x)*Math.min(1,dt*18);a.position.z+=(tg[i][1]-a.position.z)*Math.min(1,dt*18);
  if(fall[i]){const u=Math.max(0,ft-.12);a.position.y=-u*u*14;a.rotation.z+=dt*7;a.rotation.x+=dt*4;a.scale.setScalar(Math.max(.2,1-u*.6))}
  else a.position.y=Math.abs(Math.sin(t*3))*.03;
  if(shake>0&&!fall[i])a.position.x+=Math.sin(t*90)*.05;
  w.anim.forEach((o,j)=>o.rotation.y=t*.6+j);w.gl.material.opacity=.65+Math.sin(t*3+i)*.2;w.pl.intensity=2+Math.sin(t*4)*.7;w.ring.rotation.z=t;
  w.pts.rotation.y=t*.03;w.pts.position.y=Math.sin(t*.5)*.2;
  w.crates.forEach(o=>{const q=o.userData.t;o.position.x+=(q[0]-o.position.x)*k;o.position.z+=(q[1]-o.position.z)*k});
  w.plates.forEach(o=>{const u=o.m.userData,mt=u.top.material;o.m.position.y+=((u.on?-.03:0)-o.m.position.y)*k;mt.emissiveIntensity+=((u.on?1.8:.2)-mt.emissiveIntensity)*k});
  [...w.gates,...w.doors].forEach(o=>{const u=o.m.userData,g=u.bars||u.body;g.scale.y+=((u.open?.02:1)-g.scale.y)*k;g.visible=g.scale.y>.06});
  w.keys.forEach((o,j)=>{const q=o.m;q.visible=!q.userData.got;q.rotation.y=t*2;q.position.y=.55+Math.sin(t*3+j)*.05});
  if(!fall[i]){a.userData.sh.material.opacity+=((act==i?.75:.2)-a.userData.sh.material.opacity)*k;a.userData.pl.intensity=act==i?1.4:.5}
  ren.setViewport(i*hw,0,hw,ch);ren.setScissor(i*hw,0,hw,ch);ren.render(w.s,cam)})})();
