// ===== MIMIC rendering + campaign menu + navigation (added in v3; MIRROR code above is unchanged except where noted) =====
const app=$('app'),menuEl=$('menu'),lvsel=$('lvsel'),lsg=$('lsg'),lst=$('lst'),lss=$('lss'),eq=$('eq'),b3=$('b3'),b4=$('b4'),mt2=$('mt2'),cvm=$('cvm'),cvr=$('cvr');
let PG={mimic:1,mirror:1};try{const q=JSON.parse(localStorage.getItem('echobound.progress')||'{}');PG.mimic=q.mimic||1;PG.mirror=q.mirror||1}catch(e){}
const saveProg=()=>{const n=mode==='mimic'?MLV.length:LV.length;PG[mode]=Math.min(n,Math.max(PG[mode],li+2));try{localStorage.setItem('echobound.progress',JSON.stringify(PG))}catch(e){}};
const AR={u:'↑',d:'↓',l:'←',r:'→',w:'•'};
function mkEcho(s,lv){const g=figure(0x35e0d0,0x40e0ff);[0,1,2].forEach(i=>{const o=g.children[i];o.material=o.material.clone();o.material.transparent=true;o.material.opacity=.78});
 g.traverse(o=>{if(o.isMesh)o.castShadow=true});g.visible=!!lv.dl;s.add(g);return g}
let mfall=0;
function mSync(){const w=mw;
 w.crates.forEach((o,j)=>o.userData.t=[MS.cr[j][0]-3,MS.cr[j][1]-3]);
 w.plates.forEach(o=>o.m.userData.on=mOcc(MS,o.c,o.r));
 w.gates.forEach(o=>o.m.userData.open=mGate(MP,MS,o.ch));
 const lv=MP.lv;eq.innerHTML=lv.dl?'ECHO NEXT <span>'+(MS.q.length<lv.dl?'· '.repeat(lv.dl-MS.q.length):'')+MS.q.map(a=>AR[a]).join(' ')+'</span>':''}
function mLoad(i){mode='mimic';scr=null;app.className='mimic';li=i;const lv=MLV[i];MP=mParse(lv);MS=mInit(MP);hist=[];moves=0;state='play';mfall=0;ft=0;shake=0;b2.style.display='';
 L={n:'LEVEL '+(i+1),t:lv.n,mx:lv.mx};
 mw=build(MP.maps,'u',false,{cr:MP.cr,ex:lv.xp,ex2:lv.dl?lv.xe:null,fc:[0xff8a5c,0xffc247]});
 mw.echo=mkEcho(mw.s,lv);mw.ac.position.set(lv.p[0]-3,0,lv.p[1]-3);if(lv.dl)mw.echo.position.set(lv.e[0]-3,0,lv.e[1]-3);
 mt2.innerHTML=lv.dl?'Your echo repeats every move<br><b>'+lv.dl+'</b> step'+(lv.dl>1?'s':'')+' later. <kbd>Space</kbd> wait':'No echo yet.<br>Walk to the golden exit.';
 mSync();lvn.textContent=L.n;lvt.textContent=L.t;hud();ov.classList.remove('on')}
function mAct(a){if(state!=='play')return;const t=mStep(MP,MS,a);if(!t){shake=.25;return}
 hist.push(MS);MS=t;moves++;hud();mSync();
 if(t.dead){state='falling';mfall=t.dead;ft=0;shake=.5;flash();return}
 if(mWon(MP,t)){state='won';setTimeout(win,450)}else if(moves>=L.mx){state='lost';setTimeout(()=>lose('OUT OF MOVES','You used all '+L.mx+' moves.'),600)}}
const mMoveKey=(dx,dy)=>mAct(dx<0?'l':dx>0?'r':dy<0?'u':'d');
const mUndo=()=>{if(state!=='play'||!hist.length)return;MS=hist.pop();moves--;hud();mSync()};
function mLoop(dt,t){shake=Math.max(0,shake-dt);
 if(state==='falling'){ft+=dt;if(ft>1.1)lose(mfall==1?'YOU FELL':'YOUR ECHO FELL','Mind the gaps — your echo repeats your moves too.')}
 const w=mw,asp=cw/ch,dist=17*Math.max(1,1/asp*.95),k=Math.min(1,dt*14);
 cam.aspect=asp;cam.position.set(0,dist*.72,dist*.7);cam.lookAt(0,-.2,.2);cam.updateProjectionMatrix();
 const fig=(a,p,dead,ph)=>{a.position.x+=(p[0]-3-a.position.x)*Math.min(1,dt*18);a.position.z+=(p[1]-3-a.position.z)*Math.min(1,dt*18);
  if(dead){const u=Math.max(0,ft-.12);a.position.y=-u*u*14;a.rotation.z+=dt*7;a.rotation.x+=dt*4;a.scale.setScalar(Math.max(.2,1-u*.6))}
  else{a.position.y=Math.abs(Math.sin(t*3+ph))*.03;if(shake>0)a.position.x+=Math.sin(t*90)*.05}};
 fig(w.ac,MS.p,mfall==1,0);if(MS.e){fig(w.echo,MS.e,mfall==2,1.5);w.echo.children[0].material.opacity=.6+Math.sin(t*4)*.15;w.echo.userData.pl.intensity=1.2+Math.sin(t*4)*.4}
 w.ac.userData.pl.intensity=1.4;
 w.anim.forEach((o,j)=>o.rotation.y=t*.6+j);w.gl.material.opacity=.65+Math.sin(t*3)*.2;w.pl.intensity=2+Math.sin(t*4)*.7;w.ring.rotation.z=t;w.pts.rotation.y=t*.03;w.pts.position.y=Math.sin(t*.5)*.2;
 w.crates.forEach(o=>{const q=o.userData.t;o.position.x+=(q[0]-o.position.x)*k;o.position.z+=(q[1]-o.position.z)*k});
 w.plates.forEach(o=>{const u=o.m.userData,mt=u.top.material;o.m.position.y+=((u.on?-.03:0)-o.m.position.y)*k;mt.emissiveIntensity+=((u.on?1.8:.2)-mt.emissiveIntensity)*k});
 w.gates.forEach(o=>{const u=o.m.userData,g=u.bars;g.scale.y+=((u.open?.02:1)-g.scale.y)*k;g.visible=g.scale.y>.06});
 ren.setViewport(0,0,cw,ch);ren.setScissor(0,0,cw,ch);ren.render(w.s,cam)}
// ---- main menu: two live 3D previews rendered with the same engine ----
function initMenu(){P=parseLevel(LV[3]);
 const mp=mParse(MLV[5]);
 pv={m:build(mp.maps,'u',false,{cr:mp.cr,ex:MLV[5].xp,ex2:MLV[5].xe,fc:[0xff8a5c,0xffc247]}),r:[build(P.maps[0],'r',false),build(P.maps[1],'m',true)]};
 pv.m.echo=mkEcho(pv.m.s,MLV[5]);pv.m.ac.position.set(1-3,0,6-3);pv.m.echo.position.set(3-3,0,6-3);
 pv.r[0].ac.position.set(SC-3,0,SR-3);pv.r[1].ac.position.set(C-1-SC-3,0,SR-3);
 prs=[cvm,cvr].map(cv=>{const r=new THREE.WebGLRenderer({canvas:cv,antialias:true});r.setScissorTest(true);return r});
 $('pm').onclick=()=>showLevels('mimic');$('pr').onclick=()=>showLevels('mirror')}
function drawMenu(t,dt){if(!pv)return;const pc=new THREE.PerspectiveCamera(34,1,.1,100);
 const draw=(r,cv,scenes)=>{const w=cv.clientWidth,h=cv.clientHeight;if(!w||!h)return;if(cv.width!==Math.round(w*Math.min(devicePixelRatio,2))){r.setPixelRatio(Math.min(devicePixelRatio,2));r.setSize(w,h,false)}
  const n=scenes.length,hw=Math.floor(w/n);scenes.forEach((s,i)=>{const asp=hw/h;pc.aspect=asp;const d=17*Math.max(1,1/asp*.95)*.92;pc.position.set(Math.sin(t*.35)*1.6,d*.72,d*.7);pc.lookAt(0,-.2,.2);pc.updateProjectionMatrix();
   r.setViewport(i*hw,0,hw,h);r.setScissor(i*hw,0,hw,h);r.render(s.s,pc)})};
 const a=pv.m;a.anim.forEach((o,j)=>o.rotation.y=t*.6+j);a.gl.material.opacity=.65+Math.sin(t*3)*.2;a.ring.rotation.z=t;a.echo.position.y=Math.abs(Math.sin(t*3+1.5))*.03;a.ac.position.y=Math.abs(Math.sin(t*3))*.03;
 pv.r.forEach((w,i)=>{w.anim.forEach((o,j)=>o.rotation.y=t*.6+j);w.gl.material.opacity=.65+Math.sin(t*3+i)*.2;w.ring.rotation.z=t});
 draw(prs[0],cvm,[a]);draw(prs[1],cvr,pv.r)}
// ---- navigation ----
function showLevels(m){mode=m;scr='levels';state='menu';ov.classList.remove('on');menuEl.classList.remove('on');lvsel.className='on '+m;
 const mi=m==='mimic',n=mi?MLV.length:LV.length;lst.textContent=mi?'MIMIC':'MIRROR';lss.textContent=mi?'Every step leaves an echo. Seven gentle levels.':'Two worlds. Reversed paths. One escape.';
 lsg.innerHTML='';for(let i=0;i<n;i++){const b=document.createElement('button'),ok=i<PG[m];b.className='lt';b.disabled=!ok;
  b.innerHTML='<i>'+(i+1)+'</i><span>'+(mi?MLV[i].n:LV[i].t)+'</span><small>'+(ok?(i<PG[m]-1||PG[m]>=n&&false?'cleared':'ready'):'locked')+'</small>';
  b.onclick=()=>{lvsel.classList.remove('on');scr=null;(m==='mimic'?mLoad:load)(i)};lsg.appendChild(b)}}
function toLevels(){showLevels(mode==='mimic'?'mimic':'mirror')}
function toMenu(){scr='menu';state='menu';ov.classList.remove('on');lvsel.classList.remove('on');app.className='';menuEl.classList.add('on')}
$('lsb').onclick=toMenu;b3.onclick=toLevels;b4.onclick=toMenu;
initMenu();menuEl.classList.add('on');
