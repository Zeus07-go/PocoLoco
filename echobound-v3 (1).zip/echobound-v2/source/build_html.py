s=open('/mnt/user-data/uploads/ECHOBOUND___Two_Worlds__One_Escape.html').read()
def rep(a,b):
    global s
    assert s.count(a)==1,a;s=s.replace(a,b)
# --- markup ---
rep('<span>Move through Reality.<br><kbd>↑</kbd><kbd>→</kbd></span>','<span id="t1">You control Reality.</span>')
rep('<span>Your shadow reverses<br>every horizontal move.<br><kbd>←</kbd><kbd>↓</kbd></span>','<span>The other world reverses<br>every horizontal move.<br><kbd>Space</kbd> switch</span>')
rep('<button id="bR">↻ Restart (R)</button>','<button id="bS">⇄ Switch (Space)</button><button id="bU">↶ Undo (Z)</button><button id="bR">↻ Restart (R)</button>')
rep('<p>Use Arrow Keys or WASD to move in Reality.</p>','<p>Use Arrow Keys or WASD to move the active world.</p>')
goal='<div class="card"><div class="ic"><span class="fig gd"></span><span class="ar" style="color:var(--go)">'
i=s.index(goal)
add=('<div class="card"><div class="ic"><span class="ar" style="font-size:20px">⇄</span></div><div class="txt"><h3>SWITCH WORLDS</h3><p>Press Space or Tab (or click a world) to steer the other one.</p></div></div>\n'
     '<div class="card"><div class="ic"><span class="ar" style="font-size:20px">▣</span></div><div class="txt"><h3>ACROSS THE RIFT</h3><p>Crates push in both worlds. Plates open gates and keys open doors in the other world.</p></div></div>\n')
s=s[:i]+add+s[i:]
# --- css ---
rep('</style>','.lab{transition:opacity .2s,filter .2s;opacity:.55}.lab.act{opacity:1;filter:brightness(1.35)}#btns{flex-wrap:wrap;justify-content:flex-end;max-width:60vw}</style>')
# --- script: replace only the game section, keep the bundled three.js ---
a=s.index('const gn=7,Cl=7,Ls=1');b=s.index('</script></body>')
s=s[:a]+open('game_iife.js').read()+s[b:]
open('/mnt/user-data/outputs/ECHOBOUND_Two_Worlds_One_Escape.html','w').write(s)
print(len(s))
