// Usage: node scripts/solve.mjs   -> BFS-solves every level, prints shortest solution length.
import {LV} from './levels.js';
import {parseLevel,initState,step,won} from './logic.js';
const DIRS=[[0,-1,'U'],[0,1,'D'],[-1,0,'L'],[1,0,'R']];
const key=s=>[s.pc,s.pr,s.cr.map(a=>a.map(p=>p.join(',')).sort().join(';')).join('|'),[...s.got].sort()].join('#');
export function solve(P,limit=400000){
  const s0=initState(P),seen=new Map([[key(s0),null]]);let q=[[s0,'']],n=0;
  while(q.length){const nx=[];
    for(const [s,path] of q){ if(won(s))return path;
      for(const [dx,dy,ch] of DIRS){const t=step(P,s,dx,dy);if(!t)continue;const k=key(t);
        if(seen.has(k))continue;seen.set(k,1);if(++n>limit)return null;nx.push([t,path+ch])}}
    q=nx}
  return null;
}
if(process.argv[1].endsWith('solve.mjs'))LV.forEach((lv,i)=>{const sol=solve(parseLevel(lv));console.log(i+1,lv.t,sol===null?'UNSOLVABLE':sol.length+' moves  '+sol)});
