import vm from 'node:vm';import fs from 'node:fs';
import {LV} from './levels.js';import {parseLevel} from './logic.js';import {solve} from './solve.mjs';
let code=fs.readFileSync('/tmp/up/game_iife.js','utf8');
code=code.replace(/\}\)\(\{Group:Ie[^\n]*\}\);\s*$/,'})(globalThis.THREE_STUB);');
class V{constructor(){this.x=0;this.y=0;this.z=0}set(x,y,z){this.x=x;this.y=y;this.z=z;return this}setScalar(v){this.x=this.y=this.z=v}}
class Obj{constructor(){this.position=new V();this.scale=new V();this.scale.x=this.scale.y=this.scale.z=1;this.rotation=new V();this.userData={};this.children=[];this.material={opacity:1,emissiveIntensity:1};this.visible=true;this.isMesh=true;this.intensity=1;this.shadow={mapSize:new V(),camera:{}}}
 add(...c){this.children.push(...c)}traverse(f){f(this);this.children.forEach(c=>c.traverse(f))}clone(){return new Obj()}setAttribute(){}}
class Col{offsetHSL(){return this}multiplyScalar(){return this}clone(){return this}}
const mk=(X)=>class extends Obj{constructor(...a){super();if(X)X.call(this)}};
globalThis.THREE_STUB=new Proxy({},{get:(_,k)=>k==='Color'?Col:k==='Clock'?class{getDelta(){return .016}get elapsedTime(){return 1}}:k==='WebGLRenderer'?class{constructor(){this.shadowMap={}}setScissorTest(){}setPixelRatio(){}setSize(){}setViewport(){}setScissor(){}render(){}}:k==='PerspectiveCamera'?class extends Obj{lookAt(){}updateProjectionMatrix(){}}:k==='Fog'?class{}:k==='AdditiveBlending'?1:class extends Obj{}});
const els={};const mkcls=()=>{const s=new Set();return{toggle(c,on){on===undefined?(s.has(c)?s.delete(c):s.add(c)):(on?s.add(c):s.delete(c))},add:c=>s.add(c),remove:c=>s.delete(c),has:c=>s.has(c)}};
const el=id=>els[id]||(els[id]={id,textContent:'',innerHTML:'',clientWidth:900,clientHeight:500,offsetWidth:1,style:{},classList:mkcls(),firstChild:{style:{}},addEventListener(){},getBoundingClientRect:()=>({left:0,width:900})});
globalThis.document={getElementById:el};globalThis.devicePixelRatio=1;
const keys=[];globalThis.addEventListener=(t,f)=>{if(t==='keydown')keys.push(f)};
let raf;globalThis.requestAnimationFrame=f=>{raf=f};
vm.runInThisContext(code);
const press=k=>keys.forEach(f=>f({key:k,preventDefault(){}}));
const tick=(n=5)=>{for(let i=0;i<n;i++)raf()};tick();
const ok=(c,m)=>{console.log(c?'PASS':'FAIL',m);if(!c)process.exitCode=1};
const nm=(ch,inv)=>inv?{U:'w',D:'s',L:'d',R:'a'}[ch]:{U:'w',D:'s',L:'a',R:'d'}[ch];
for(let i=0;i<LV.length;i++){
  const path=solve(parseLevel(LV[i]));const inv=i%2===1;
  if(inv)press(' ');
  for(const ch of path){press(nm(ch,inv));tick(2)}
  await new Promise(r=>setTimeout(r,520));
  const last=i===LV.length-1;
  ok(els.ot.textContent===(last?'ALL WORLDS ESCAPED':'LEVEL COMPLETE'),`${LV[i].n} ${inv?'(Mirror-controlled)':'(Reality-controlled)'} solved in ${els.mv.textContent}/${els.mxv.textContent} (limit ${LV[i].mx})`);
  els.b1.onclick();tick(2);
}
// Level 1 again: falling and out-of-moves are not reachable in L1 (no gaps); go to L2 for a gap.
// L2: Reality gap at (6,6). Start (1,6): walk right x5 -> col 6.
els.b1.onclick&&0;
// restart to level 1 via 'r' after finishing -> then jump levels by solving none: use b1 chain
// Out of moves on L1 (limit 15): shuffle left/right 15 times
press('r');tick(2);
for(let i=0;i<15;i++){press(i%2?'a':'d');tick(1)}
await new Promise(r=>setTimeout(r,700));
ok(els.ot.textContent==='OUT OF MOVES','out of moves after 15 aimless moves');
// restart then undo
press('r');tick(2);press('w');console.log('mv after w (no tick):',els.mv.textContent);press('z');console.log('mv after z:',els.mv.textContent,'lvn',els.lvn.textContent);
// Fall: need level with gap. Level 2 is index 1: finish L1 then walk into gap.
const p1=solve(parseLevel(LV[0]));for(const ch of p1){press(nm(ch,false));tick(1)}
await new Promise(r=>setTimeout(r,520));els.b1.onclick();tick(2);
// L2 Reality gap at (6,6): start col1,row6 -> 5 x 'd'
for(let i=0;i<5;i++){press('d');tick(1)}
tick(120);
ok(els.ot.textContent==='YOU FELL','stepping into a gap makes you fall ('+els.ot.textContent+')');
console.log('--- undo debug');
press('r');tick(2);console.log('after r mv=',els.mv.textContent);
press('w');tick(2);console.log('after w mv=',els.mv.textContent);
press('z');tick(2);console.log('after z mv=',els.mv.textContent);
press('u');console.log('after u mv=',els.mv.textContent);
console.log('--- undo on level 1');
// go to level 1: finish L2.. simply restart chain: use Play Again path by loading via solving all is slow; reuse b1 after a quick L2 fall -> Try Again restarts L2.
// so test undo on L2 with an open first move instead: L2 start (1,6): 'a' left -> (0,6)? R[6][0] '.', M col6 row6 '.'
press('r');tick(2);press('a');tick(2);console.log('after a mv=',els.mv.textContent);press('z');tick(2);console.log('after z mv=',els.mv.textContent);
