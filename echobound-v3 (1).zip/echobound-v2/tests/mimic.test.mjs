import fs from 'fs';
const src=fs.readFileSync(new URL('../source/mimic_logic.js',import.meta.url),'utf8');
const {MLV,mParse,mSolve,mInit,mStep,mWon}=new Function(src+';return {MLV,mParse,mSolve,mInit,mStep,mWon}')();
let bad=0;
MLV.forEach((lv,i)=>{const P=mParse(lv),r=mSolve(P);console.log(i+1,lv.n,r?`solvable in ${r.n} (${r.path})`:'UNSOLVABLE');if(!r)bad++});
// determinism / delay checks
const P=mParse(MLV[1]);let s=mInit(P);s=mStep(P,s,'u');console.log('echo after 1 move (delay 1) still at start:',s.e+''==='5,6');
s=mStep(P,s,'u');console.log('echo after 2nd move one step behind:',s.e+''==='5,5');
process.exit(bad?1:0);
