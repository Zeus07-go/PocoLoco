import test from 'node:test';
import assert from 'node:assert/strict';
import {parseLevel,initState,step,won,gateOpen,doorOpen} from '../src/logic.js';
import {LV} from '../src/levels.js';
import {solve} from '../scripts/solve.mjs';

const lvl=(R,M)=>parseLevel({R,M});
const E='.......';
const mapOf=(rows)=>{const a=Array(7).fill(E);rows.forEach(([r,s])=>a[r]=s);return a};
const st=(P,o={})=>({...initState(P),...o});

test('every shipped level is solvable',()=>{LV.forEach((lv,i)=>assert.ok(solve(parseLevel(lv)),'level '+(i+1)))});

test('plain move mirrors horizontally, vertical is shared',()=>{
  const P=lvl(mapOf([]),mapOf([]));const s=step(P,initState(P),1,0);
  assert.deepEqual([s.pc,s.pr],[2,6]);          // Reality +1 col
  const m=step(P,s,0,-1);assert.equal(m.pr,5);
});
test('move blocked when either world is blocked',()=>{
  const P=lvl(mapOf([]),mapOf([[6,'....W..']])); // Mirror shadow at col 5 -> moving right sends it to col 4 (wall)
  assert.equal(step(P,initState(P),1,0),null);
});
test('crate is pushed in both worlds, mirrored',()=>{
  const P=lvl(mapOf([[6,'..X....']]),mapOf([[6,'....X..']]));
  const s=step(P,initState(P),1,0);
  assert.deepEqual(s.cr[0][0],[3,6]);assert.deepEqual(s.cr[1][0],[3,6]);
});
test('crate cannot be pushed into a wall, another crate or off the map',()=>{
  const P=lvl(mapOf([[6,'..XW...']]),mapOf([]));assert.equal(step(P,initState(P),1,0),null);
  const Q=lvl(mapOf([[6,'..XX...']]),mapOf([]));assert.equal(step(Q,initState(Q),1,0),null);
  const O=lvl(mapOf([[6,'X......']]),mapOf([]));assert.equal(step(O,initState(O),-1,0),null);
});
test('plate in one world opens the gate in the other (crate holds it)',()=>{
  const P=lvl(mapOf([[6,'..Xa...']]),mapOf([[5,'..A....']]));
  const s0=initState(P);assert.equal(gateOpen(P,s0,1,'A'),false);
  const s1=step(P,s0,1,0);                        // crate lands on plate (3,6)
  assert.equal(gateOpen(P,s1,1,'A'),true);
});
test('gate in a world never opens from a plate in the same world',()=>{
  const P=lvl(mapOf([[6,'..Xa...'],[5,'..A....']]),mapOf([]));
  const s1=step(P,initState(P),1,0);assert.equal(gateOpen(P,s1,0,'A'),false);
});
test('cannot step into a closed gate, and cannot release a plate under an occupied gate',()=>{
  const P=lvl(mapOf([[5,'.A.....']]),mapOf([]));assert.equal(step(P,initState(P),0,-1),null);
});
test('key opens the door in the other world only',()=>{
  const P=lvl(mapOf([[6,'..k....']]),mapOf([[5,'.....K.']]));
  const s=step(P,initState(P),1,0);
  assert.deepEqual(s.got,['0k']);assert.equal(doorOpen(s,1,'K'),true);assert.equal(doorOpen(s,0,'K'),false);
});
test('locked door blocks until key is held',()=>{
  const P=lvl(mapOf([]),mapOf([[6,'....K..']]));       // shadow would step onto K at (4,6)
  assert.equal(step(P,initState(P),1,0),null);
});
test('win only when Reality figure is on the exit',()=>{
  const P=lvl(mapOf([]),mapOf([]));assert.equal(won(st(P,{pc:5,pr:0})),true);assert.equal(won(initState(P)),false);
});
