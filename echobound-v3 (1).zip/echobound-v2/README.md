# ECHOBOUND v3 — MIMIC campaign + main menu added
ECHOBOUND_Two_Worlds_One_Escape.html  - playable single file (three.js bundled, offline)
source/mimic_logic.js   - MIMIC rules + 7 levels (pure JS, unit-testable)
source/mimic_main.js    - MIMIC rendering, main menu (live 3D previews), level select, navigation
source/css_v3.css       - menu / MIMIC warm theme styles
source/audio.js         - procedural WebAudio music + sound effects (M key / Sound button to mute)
source/game_iife.js     - full game script (MIRROR code + the v3 additions)
source/build_v3.py      - splices CSS, markup and script into the v2 HTML:  python3 source/build_v3.py . <v2 html>
tests/mimic.test.mjs    - BFS-solves all 7 MIMIC levels:  node tests/mimic.test.mjs
MIMIC: echo repeats your moves N actions later (Space = wait). Hero exit gold, echo exit turquoise.
Progress is stored separately per campaign (localStorage key echobound.progress).
