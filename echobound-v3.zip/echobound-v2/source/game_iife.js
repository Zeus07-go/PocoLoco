((THREE)=>{
const $=id=>document.getElementById(id);const [b1,b2,bR,bM,bS,bU,ot,os,ov,mv,mxv,info,bar,c,lr,lm,t1,fx,lvn,lvt,stage]=['b1','b2','bR','bM','bS','bU','ot','os','ov','mv','mxv','info','bar','c','lr','lm','t1','fx','lvn','lvt','stage'].map($);
// Level data. R = Reality map, M = Mirror map (both "as displayed").
//  .  floor      W  wall      #  gap
//  X  pushable crate (pushed in both worlds, mirrored)
//  a b  pressure plates -> open gates A B in the OTHER world while occupied (figure or crate)
//  k l  keys            -> unlock doors K L in the OTHER world once picked up
const C=7,R=7,SC=1,SR=6,EC=5,ER=0;
const LV=[
{n:'LEVEL 1',t:'FIRST STEPS',mx:15,R:['.......','.......','..WW...','.......','.......','.......','.......'],M:['.......','.......','...W...','.......','.......','.......','.......']},
{n:'LEVEL 2',t:'THE REFLECTION',mx:16,R:['W......','.......','W......','......W','...WW..','.W.W...','......#'],M:['...W...','....#..','.......','#WW....','WW..W..','#....W.','..W##..']},
{n:'LEVEL 3',t:'THE FRACTURE',mx:22,R:['W.....W','.......','.....W.','.......','.....#.','.W.W...','...WW..'],M:['W.W.W..','..W....','....W.W','....W..','.W.WWW.','W#..WW.','...#W..']},
{n:'LEVEL 4',t:'HEAVY ECHO',mx:22,R:['....W.#','.......','...W..#','...WW..','...#...','.W.....','X..W...'],M:['.....X.','#...W..','W.....W','..W..WW','..W....','X.W...W','.......']},
{n:'LEVEL 5',t:'SKELETON KEYS',mx:24,R:['......W','.....W#','..lW..W','.#...W.','...W...','..W..K.','..W#...'],M:['W..L...','W...W..','k..W.W.','...W...','.#.....','W......','....W..']},
{n:'LEVEL 6',t:'THE WEIGHT BETWEEN',mx:32,R:['....W.#','.....A.','...W..#','...WW..','...#...','.W.....','...W...'],M:['.....W.','#...W..','W.....W','..W..WW','aXW....','.....W.','.......']},
{n:'LEVEL 7',t:'CONVERGENCE',mx:28,R:['.#.....','.......','..W.#.W','..#...W','...W..W','..WWXkW','W..Wa..'],M:['W..W...','..K....','..W....','.W..W..','.W.W..W','.A....W','......W']}];

// Pure game rules (no rendering). World 0 = Reality, world 1 = Mirror.
// Maps are "as displayed", so the Mirror figure's column is C-1-pc.
// Tile legend:  . floor   W wall   # gap   X pushable crate (on floor)
//   a b  pressure plates   -> open the matching gate (A B) in the OTHER world
//   A B  gates             -> open while the matching plate in the other world is occupied
//   k l  keys              -> picking one up unlocks the matching door (K L) in the OTHER world
//   K L  locked doors


const KEYS='kl',GATES='AB',DOORS='KL';
const inb=(c,r)=>c>=0&&c<C&&r>=0&&r<R;

function parseLevel(lv){
  const maps=[],crates=[[],[]],at=[{},{}];
  [lv.R,lv.M].forEach((rows,w)=>{
    maps[w]=rows.map((row,r)=>[...row].map((ch,c)=>{
      if(ch==='X'){crates[w].push([c,r]);return '.'}
      (at[w][ch]=at[w][ch]||[]).push([c,r]);return ch}));
  });
  return {maps,crates,at};
}
const initState=P=>({pc:SC,pr:SR,cr:P.crates.map(a=>a.map(p=>[...p])),got:[]});
const cloneState=s=>({pc:s.pc,pr:s.pr,cr:s.cr.map(a=>a.map(p=>[...p])),got:[...s.got]});
const figures=s=>[[s.pc,s.pr],[C-1-s.pc,s.pr]];

// Is a figure or crate standing on this cell of world w?
function occupied(s,w,c,r){
  const f=figures(s)[w];
  return (f[0]===c&&f[1]===r)||s.cr[w].some(q=>q[0]===c&&q[1]===r);
}
// Gate X in world w is open while plate x (lowercase) in the other world is occupied.
function gateOpen(P,s,w,ch){
  return (P.at[1-w][ch.toLowerCase()]||[]).some(([c,r])=>occupied(s,1-w,c,r));
}
// Door X in world w is open once key x was picked up in the other world.
const doorOpen=(s,w,ch)=>s.got.includes((1-w)+ch.toLowerCase());

const baseSolid=(P,w,c,r)=>!inb(c,r)||P.maps[w][r][c]==='W'||P.maps[w][r][c]==='#';
function solid(P,s,w,c,r){
  if(baseSolid(P,w,c,r))return true;
  const ch=P.maps[w][r][c];
  if(GATES.includes(ch))return !gateOpen(P,s,w,ch);
  if(DOORS.includes(ch))return !doorOpen(s,w,ch);
  return false;
}

// rdx = horizontal step in Reality (Mirror moves -rdx), dy = vertical step in both.
// Returns the new state, or null if the move is illegal in either world.
function step(P,s,rdx,dy,allowGap=false){
  const n=cloneState(s);n.pc+=rdx;n.pr+=dy;
  const d=[[rdx,dy],[-rdx,dy]],to=figures(n);
  for(let w=0;w<2;w++){
    const [tc,tr]=to[w];
    const gap=allowGap&&inb(tc,tr)&&P.maps[w][tr][tc]==='#';
    if(baseSolid(P,w,tc,tr)&&!gap)return null;
    const i=n.cr[w].findIndex(q=>q[0]===tc&&q[1]===tr);
    if(i>=0){ // push one crate; no chains
      const nc=tc+d[w][0],nr=tr+d[w][1];
      if(baseSolid(P,w,nc,nr)||n.cr[w].some(q=>q[0]===nc&&q[1]===nr))return null;
      n.cr[w][i]=[nc,nr];
    }
    const ch=P.maps[w][tr][tc];
    if(KEYS.includes(ch)&&!n.got.includes(w+ch))n.got.push(w+ch);
  }
  // Settled state must be legal: nothing may stand in a closed gate or locked door
  // (this also forbids leaving a plate while something stands in the gate it feeds).
  const f=figures(n);
  for(let w=0;w<2;w++){
    if(solid(P,n,w,f[w][0],f[w][1])&&!(allowGap&&P.maps[w][f[w][1]][f[w][0]]==='#'))return null;
    for(const q of n.cr[w])if(solid(P,n,w,q[0],q[1]))return null;
  }
  return n;
}
const won=s=>s.pc===EC&&s.pr===ER;





let mode='menu',scr='menu',MP,MS,mw,pv=null,prs=null;
// MIMIC rules (pure). One world, one hero, one echo that repeats the hero's moves D actions later.
// Tiles: . floor  W wall  # gap  X crate  a b plates  A B gates (same world; open while a plate is occupied by hero, echo or crate)
// Actions: u d l r move, w wait (recorded too, so the echo can catch up).
const MDIR={u:[0,-1],d:[0,1],l:[-1,0],r:[1,0],w:[0,0]};
const MC=7,MR=7;
const mIn=(c,r)=>c>=0&&c<MC&&r>=0&&r<MR;
function mParse(lv){const maps=lv.M.map(row=>[...row]),cr=[],pl={};
  maps.forEach((row,r)=>row.forEach((ch,c)=>{if(ch==='X'){cr.push([c,r]);row[c]='.'}else if('ab'.includes(ch))(pl[ch]=pl[ch]||[]).push([c,r])}));
  return {maps,cr,pl,lv}}
const mInit=P=>({p:[...P.lv.p],e:P.lv.dl?[...P.lv.e]:null,q:[],cr:P.cr.map(a=>[...a]),dead:0});
const mOcc=(s,c,r)=>(s.p[0]===c&&s.p[1]===r)||(s.e&&s.e[0]===c&&s.e[1]===r)||s.cr.some(q=>q[0]===c&&q[1]===r);
const mGate=(P,s,ch)=>(P.pl[ch.toLowerCase()]||[]).some(([c,r])=>mOcc(s,c,r));
// blocked for walking (gaps are NOT blocked: stepping in means falling)
function mBlock(P,s,c,r){if(!mIn(c,r))return true;const ch=P.maps[r][c];return ch==='W'||('AB'.includes(ch)&&!mGate(P,s,ch))}
// move one actor (0 hero, 1 echo) in state n (mutates n). Returns false if blocked.
function mMove(P,n,who,a){const [dx,dy]=MDIR[a],f=who?n.e:n.p,o=who?n.p:n.e,t=[f[0]+dx,f[1]+dy];
  if(a==='w')return true;
  if(mBlock(P,n,t[0],t[1])||(o&&o[0]===t[0]&&o[1]===t[1]))return false;
  const i=n.cr.findIndex(q=>q[0]===t[0]&&q[1]===t[1]);
  if(i>=0){const u=[t[0]+dx,t[1]+dy];
    if(mBlock(P,n,u[0],u[1])||P.maps[u[1]]&&P.maps[u[1]][u[0]]==='#'||n.cr.some(q=>q[0]===u[0]&&q[1]===u[1])||(o&&o[0]===u[0]&&o[1]===u[1])||(f[0]===u[0]&&f[1]===u[1]))return false;
    n.cr[i]=u}
  f[0]=t[0];f[1]=t[1];if(P.maps[t[1]][t[0]]==='#')n.dead=who+1;return true}
function mStep(P,s,a){if(s.dead)return null;
  const n={p:[...s.p],e:s.e&&[...s.e],q:[...s.q],cr:s.cr.map(q=>[...q]),dead:0};
  if(a!=='w'&&!mMove(P,n,0,a))return null;
  if(n.e){n.q.push(a);if(n.q.length>P.lv.dl&&!n.dead){const m=n.q.shift();mMove(P,n,1,m)}}
  if(!n.dead){ // settled state: nothing may stand in a closed gate
    const bad=(c,r)=>'AB'.includes(P.maps[r][c])&&!mGate(P,n,P.maps[r][c]);
    if(bad(n.p[0],n.p[1])||(n.e&&bad(n.e[0],n.e[1]))||n.cr.some(q=>bad(q[0],q[1])))return null}
  return n}
const mWon=(P,s)=>!s.dead&&s.p[0]===P.lv.xp[0]&&s.p[1]===P.lv.xp[1]&&(!P.lv.dl||(s.e[0]===P.lv.xe[0]&&s.e[1]===P.lv.xe[1]));
const mKey=s=>[s.p,s.e,s.q.join(''),s.cr.map(q=>q.join()).sort().join(';')].join('|');
// BFS: shortest solution length, or -1
function mSolve(P,cap=60){const s0=mInit(P);let cur=[[s0,[]]],seen=new Set([mKey(s0)]);
  for(let d=0;d<=cap;d++){const nx=[];for(const [s,h] of cur){if(mWon(P,s))return {n:d,path:h.join('')};
    for(const a of 'udlrw'){const t=mStep(P,s,a);if(t&&!t.dead||t&&t.dead){if(t.dead)continue;const k=mKey(t);if(!seen.has(k)){seen.add(k);nx.push([t,[...h,a]])}}}}
    cur=nx;if(!cur.length)return null}return null}
const MLV=[
{n:'SUNLIT GARDEN',mx:16,dl:0,p:[1,6],xp:[5,0],M:['.......','.......','..WW...','.......','.......','.......','.......']},
{n:'FOLLOW MY LIGHT',mx:15,dl:1,p:[1,6],e:[5,6],xp:[1,0],xe:[5,0],M:['.......','.......','.W...W.','.......','.......','.......','.......']},
{n:'TWIN PATHS',mx:15,dl:2,p:[0,6],e:[6,6],xp:[0,0],xe:[6,0],M:['.......','..W.W..','.......','W..W...','.......','.W...W.','.......']},
{n:'THE GENTLE BRIDGE',mx:14,dl:2,p:[1,6],e:[5,6],xp:[1,0],xe:[5,0],M:['.......','..#.#..','.......','#.###.#','.......','.......','.......']},
{n:'LITTLE HELPERS',mx:16,dl:2,p:[1,6],e:[5,6],xp:[1,0],xe:[5,0],M:['.......','.....W.','.......','.......','.....X.','.......','.......']},
{n:'THE SUN GATE',mx:19,dl:2,p:[1,6],e:[3,6],xp:[1,0],xe:[5,0],M:['.......','.......','WW.AW.W','..X....','...a...','.......','.......']},
{n:'TOGETHER HOME',mx:27,dl:2,p:[1,6],e:[3,6],xp:[1,0],xe:[5,0],M:['.......','..#.#..','WW.AW.W','..X....','...a...','.#...#.','.......']}];

const T={
 r:{bg:0x0b2a4d,fog:0x12457a,stone:[0x5d7690,0x6a86a3],wall:0x7b97b4,cr:0x5fe6ff,lan:0x59c8ff,sky:0x9fd8ff,gnd:0x1a3a66,key:0xaad4ff,pt:0x44ccff,ac:0x2fa8ff},
 m:{bg:0x1a0b33,fog:0x2e1456,stone:[0x4b3a6e,0x57447c],wall:0x5d4a8a,cr:0xffc14a,lan:0xffa030,sky:0xb890ff,gnd:0x2a1148,key:0xd7b0ff,pt:0xffb040,ac:0xffb23a},
 u:{bg:0xf6b98c,fog:0xefa878,stone:[0xd9b06a,0xcf9f5c],wall:0xd98650,cr:0x35d6c8,lan:0xff8f55,sky:0xffd9a3,gnd:0xb9783f,key:0xffd890,pt:0xffc247,ac:0xffb347}};
let L,P,S,hist=[],act=0,li=0,moves=0,state='play',shake=0,W=[],fall=[false,false],ft=0;
const rn=(a,b)=>{const x=Math.sin(a*127.1+b*311.7)*43758.5453;return x-Math.floor(x)};
const std=(c,o={})=>new THREE.MeshStandardMaterial(Object.assign({color:c,flatShading:true,roughness:.85,metalness:.05},o));
function crystal(col,s){const g=new THREE.Group(),m=new THREE.MeshStandardMaterial({color:col,emissive:col,emissiveIntensity:1.1,flatShading:true,roughness:.2});
 for(let i=0;i<3;i++){const o=new THREE.Mesh(new THREE.OctahedronGeometry(.1*s*(1-i*.2)),m);o.scale.y=2.2;o.position.set((i-1)*.1*s,.1*s*(2-i*.4),i%2*.06);o.rotation.y=i;g.add(o)}return g}
function lantern(col){const g=new THREE.Group();const b=new THREE.Mesh(new THREE.BoxGeometry(.22,.06,.22),std(0x2a2f3a));const p=new THREE.Mesh(new THREE.BoxGeometry(.04,.3,.04),std(0x2a2f3a));p.position.y=.18;
 const l=new THREE.Mesh(new THREE.BoxGeometry(.2,.22,.2),new THREE.MeshStandardMaterial({color:col,emissive:col,emissiveIntensity:1.6}));l.position.y=.42;const pl=new THREE.PointLight(col,.7,3);pl.position.y=.45;g.add(b,p,l,pl);return g}

const PC={a:0x56f08a,b:0xff5ad1,k:0xfff070,l:0xff6a5a};
const glowM=(c,i)=>new THREE.MeshStandardMaterial({color:c,emissive:c,emissiveIntensity:i,flatShading:true,roughness:.4});
const bx=(w,h,d,m,x,y,z)=>{const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);o.position.set(x,y,z);o.castShadow=true;return o};
function plateMesh(col){const g=new THREE.Group(),top=new THREE.Mesh(new THREE.BoxGeometry(.6,.05,.6),glowM(col,.2));top.position.y=.04;
 g.add(new THREE.Mesh(new THREE.BoxGeometry(.78,.06,.78),std(0x2a2f3a)),top);g.userData.top=top;return g}
function gateMesh(col){const g=new THREE.Group(),bars=new THREE.Group(),m=glowM(col,.9);
 [-.32,0,.32].forEach(x=>bars.add(bx(.1,1,.1,m,x,.5,0)));bars.add(bx(.84,.1,.1,m,0,.85,0),bx(.84,.1,.1,m,0,.3,0));
 g.add(bars,bx(.8,.03,.8,glowM(col,.5),0,.02,0));g.userData.bars=bars;return g}
function keyMesh(col){const g=new THREE.Group(),m=glowM(col,1.1),r=new THREE.Mesh(new THREE.TorusGeometry(.11,.04,6,12),m);r.position.y=.2;
 g.add(r,bx(.05,.3,.05,m,0,0,0),bx(.12,.05,.05,m,.06,-.1,0),bx(.09,.05,.05,m,.045,-.02,0));g.position.y=.55;return g}
function doorMesh(col){const g=new THREE.Group(),body=new THREE.Group();
 body.add(bx(.95,1.1,.95,std(new THREE.Color(col).multiplyScalar(.35)),0,.55,0),bx(.14,.2,.02,glowM(col,1.4),0,.6,.49),bx(1.02,.1,1.02,glowM(col,.6),0,1.14,0));
 g.add(body);g.userData.body=body;return g}
function crateMesh(t){const g=new THREE.Group(),col=new THREE.Color(t.cr);
 g.add(bx(.78,.78,.78,std(col.clone().multiplyScalar(.45)),0,0,0),bx(.84,.1,.84,glowM(t.cr,.35),0,0,0),bx(.1,.84,.1,glowM(t.cr,.35),0,0,.4),bx(.1,.84,.1,glowM(t.cr,.35),0,0,-.4));
 g.traverse(o=>{if(o.isMesh)o.receiveShadow=true});return g}
function figure(col,glow){const g=new THREE.Group(),m=new THREE.MeshStandardMaterial({color:col,emissive:col,emissiveIntensity:.5,flatShading:true});
 const body=new THREE.Mesh(new THREE.ConeGeometry(.24,.62,7),m);body.position.y=.31;const head=new THREE.Mesh(new THREE.SphereGeometry(.15,10,8),m);head.position.y=.72;
 const hood=new THREE.Mesh(new THREE.ConeGeometry(.17,.22,7),m);hood.position.y=.88;
 const sig=new THREE.Mesh(new THREE.BoxGeometry(.09,.09,.02),new THREE.MeshBasicMaterial({color:0xffffff}));sig.position.set(0,.4,.2);sig.rotation.z=.78;
 const sh=new THREE.Mesh(new THREE.CircleGeometry(.3,16),new THREE.MeshBasicMaterial({color:glow,transparent:true,opacity:.35}));sh.rotation.x=-Math.PI/2;sh.position.y=.02;
 const pl=new THREE.PointLight(glow,1.2,3.5);pl.position.y=.9;g.add(body,head,hood,sig,sh,pl);g.userData.sh=sh;g.userData.pl=pl;return g}
function build(map,th,mir,o){
 const s=new THREE.Scene(),t=T[th];s.background=new THREE.Color(t.bg);s.fog=new THREE.Fog(t.fog,14,42);
 s.add(new THREE.HemisphereLight(t.sky,t.gnd,.9));
 const d=new THREE.DirectionalLight(t.key,.9);d.position.set(mir?-6:6,12,8);d.castShadow=true;d.shadow.mapSize.set(1024,1024);const sc=d.shadow.camera;sc.left=sc.bottom=-8;sc.right=sc.top=8;s.add(d);
 const anim=[],dyn={plates:[],gates:[],keys:[],doors:[]},tx=c=>c-3,tz=r=>r-3,put=(m,c,r)=>{m.position.x=tx(c);m.position.z=tz(r);s.add(m);return m};
 for(let r=0;r<R;r++)for(let c=0;c<C;c++){const ch=map[r][c];if(ch=='#')continue;const h=rn(c,r+(mir?9:0));
  const col=new THREE.Color(t.stone[h>.5?1:0]).offsetHSL(0,0,(h-.5)*.08);
  const tile=new THREE.Mesh(new THREE.BoxGeometry(.97,.5,.97),std(col));tile.position.set(tx(c),-.25,tz(r));tile.receiveShadow=true;s.add(tile);
  const rock=new THREE.Mesh(new THREE.ConeGeometry(.62,1.4+h*1.6,4),std(new THREE.Color(t.stone[0]).multiplyScalar(.6)));rock.rotation.set(Math.PI,Math.PI/4,0);rock.position.set(tx(c),-1.2-h*.8,tz(r));s.add(rock);
  if(ch=='a'||ch=='b')dyn.plates.push({m:put(plateMesh(PC[ch]),c,r),c,r});
  else if(ch=='A'||ch=='B')dyn.gates.push({m:put(gateMesh(PC[ch.toLowerCase()]),c,r),ch});
  else if(ch=='k'||ch=='l')dyn.keys.push({m:put(keyMesh(PC[ch]),c,r),ch});
  else if(ch=='K'||ch=='L')dyn.doors.push({m:put(doorMesh(PC[ch.toLowerCase()]),c,r),ch});
  if(ch=='W'){const hh=1+Math.floor(h*2)*.0;const w=new THREE.Mesh(new THREE.BoxGeometry(.95,1.1,.95),std(t.wall));w.position.set(tx(c),.55,tz(r));w.castShadow=w.receiveShadow=true;s.add(w);
   const cap=new THREE.Mesh(new THREE.BoxGeometry(1.02,.12,1.02),std(new THREE.Color(t.wall).multiplyScalar(1.25)));cap.position.set(tx(c),1.14,tz(r));s.add(cap);
   if(h>.82){const cr=crystal(t.cr,1.1);cr.position.set(tx(c),1.2,tz(r));s.add(cr);anim.push(cr)}}
  else if(ch=='.'&&h>.9&&!(c==(mir?C-1-SC:SC)&&r==SR)){const o=h>.95?lantern(t.lan):crystal(t.cr,1);o.position.set(tx(c)+.28,0,tz(r)+.28);s.add(o);anim.push(o)}
 }
 const crates=(o&&o.cr||P.crates[mir?1:0]).map(([c,r])=>{const m=crateMesh(t);put(m,c,r);m.position.y=.4;m.userData.t=[c-3,r-3];return m});
 // far floating ruins
 for(let i=0;i<22;i++){const a=rn(i,mir?3:1)*6.28,rad=7+rn(i,5)*10,hh=1+rn(i,7)*4;const g=new THREE.Group();
  const b=new THREE.Mesh(new THREE.BoxGeometry(1+rn(i,2)*1.6,hh,1+rn(i,4)*1.6),std(t.stone[0]));const k=new THREE.Mesh(new THREE.ConeGeometry(.9,1.8,4),std(t.stone[0]));k.rotation.x=Math.PI;k.position.y=-hh/2-.9;g.add(b,k);
  g.position.set(Math.cos(a)*rad,-2-rn(i,8)*7+hh/2,Math.sin(a)*rad-4);s.add(g)}
 // exit portal
 const ex0=o&&o.ex||[mir?C-1-EC:EC,ER],ec=ex0[0],p=new THREE.Group(),pm=new THREE.MeshStandardMaterial({color:t.stone[1],flatShading:true});
 [-.4,.4].forEach(x=>{const pi=new THREE.Mesh(new THREE.BoxGeometry(.2,1.5,.3),pm);pi.position.set(x,.75,0);p.add(pi)});
 const top=new THREE.Mesh(new THREE.TorusGeometry(.4,.1,6,10,Math.PI),pm);top.position.y=1.5;p.add(top);
 const gl=new THREE.Mesh(new THREE.CircleGeometry(.36,24),new THREE.MeshBasicMaterial({color:t.pt,transparent:true,opacity:.85,blending:THREE.AdditiveBlending}));gl.position.set(0,.92,.02);
 const gl2=new THREE.Mesh(new THREE.PlaneGeometry(.72,1.5),gl.material);gl2.position.set(0,.75,.01);p.add(gl,gl2);
 const pl=new THREE.PointLight(t.pt,2,6);pl.position.set(0,1,.8);p.add(pl);
 const ring=new THREE.Mesh(new THREE.TorusGeometry(.42,.03,6,24),new THREE.MeshBasicMaterial({color:t.pt}));ring.rotation.x=Math.PI/2;ring.position.y=.04;p.add(ring);
 p.position.set(tx(ec),0,tz(ex0[1]));s.add(p);
 if(o&&o.ex2){const p2=p.clone(true);p2.traverse(q=>{if(q.material){q.material=q.material.clone();q.material.color.set(0x35e0d0)}if(q.isLight)q.color.set(0x35e0d0)});p2.position.set(tx(o.ex2[0]),0,tz(o.ex2[1]));s.add(p2)}
 // particles
 const pg=new THREE.BufferGeometry(),pa=[];for(let i=0;i<140;i++)pa.push((Math.random()-.5)*14,Math.random()*7-1,(Math.random()-.5)*14);
 pg.setAttribute('position',new THREE.Float32BufferAttribute(pa,3));const pts=new THREE.Points(pg,new THREE.PointsMaterial({color:t.pt,size:.07,transparent:true,opacity:.8}));s.add(pts);
 const fc=(o&&o.fc)||[mir?0xffc247:0x3f9bff,mir?0xffa830:0x44aaff],ac=figure(fc[0],fc[1]);ac.traverse(o=>{if(o.isMesh)o.castShadow=true});s.add(ac);
 return {s,anim,ac,gl,pl,ring,pts,ex:p,crates,...dyn};
}
function sync(){W.forEach((w,i)=>{
 w.crates.forEach((o,j)=>o.userData.t=[S.cr[i][j][0]-3,S.cr[i][j][1]-3]);
 w.plates.forEach(o=>o.m.userData.on=occupied(S,i,o.c,o.r));
 w.gates.forEach(o=>o.m.userData.open=gateOpen(P,S,i,o.ch));
 w.doors.forEach(o=>o.m.userData.open=doorOpen(S,i,o.ch));
 w.keys.forEach(o=>o.m.userData.got=S.got.includes(i+o.ch))})}
function setAct(a){act=a;lr.classList.toggle('act',a==0);lm.classList.toggle('act',a==1);
 t1.innerHTML=a?'You control the Mirror.<br>Reality mirrors you.':'You control Reality.<br>The Mirror mirrors you.'}
const switchWorld=()=>{if(state==='play'&&mode==='mirror')setAct(1-act)};
function hud(){const left=L.mx-moves;mv.textContent=moves;mxv.textContent=L.mx;info.classList.toggle('low',left<=3);bar.firstChild.style.width=Math.max(0,left/L.mx*100)+'%'}
function flash(){fx.classList.remove('on');fx.offsetWidth;fx.classList.add('on')}
function load(i){mode='mirror';scr=null;app.className='';li=i;L=LV[i];P=parseLevel(L);S=initState(P);hist=[];moves=0;state='play';fall=[false,false];ft=0;shake=0;b2.style.display='';
 W=[build(P.maps[0],'r',false),build(P.maps[1],'m',true)];
 W[0].ac.position.set(S.pc-3,0,S.pr-3);W[1].ac.position.set(C-1-S.pc-3,0,S.pr-3);
 sync();setAct(0);lvn.textContent=L.n;lvt.textContent=L.t;hud();ov.classList.remove('on')}
function lose(t,sub){state='lost';ot.textContent=t;os.textContent=sub;b1.textContent='Try Again';b1.onclick=restart;b2.style.display='none';ov.classList.add('on')}
// dx is the direction pressed on the ACTIVE world; Reality's horizontal step is flipped when the Mirror is active.
function moveR(dx,dy){if(state!=='play')return;const t=step(P,S,act?-dx:dx,dy,true);
 if(!t){shake=.25;return}
 hist.push(S);S=t;moves++;hud();sync();
 const g=figures(S).map((p,w)=>P.maps[w][p[1]][p[0]]==='#');
 if(g[0]||g[1]){state='falling';fall=g;ft=0;shake=.5;flash();return}
 if(won(S)){state='won';setTimeout(win,450)}
 else if(moves>=L.mx){state='lost';shake=.3;setTimeout(()=>lose('OUT OF MOVES','You used all '+L.mx+' moves.'),600)}}
function undoR(){if(state!=='play'||!hist.length)return;S=hist.pop();moves--;hud();sync()}
function win(){const mi=mode==='mimic',n=mi?MLV.length:LV.length,last=li==n-1;saveProg();
 ot.textContent=last?(mi?'ALL ECHOES HOME':'ALL WORLDS ESCAPED'):'LEVEL COMPLETE';os.textContent=(mi?'Hero and echo made it in ':'Both exits reached in ')+moves+' moves.';
 b2.style.display='';b1.textContent=last?'Main Menu':'Next Level';b1.onclick=last?toMenu:()=>go(li+1);ov.classList.add('on')}
function menu(){if(state!=='play'&&state!=='paused')return;if(state==='paused'){resume();return}state='paused';b2.style.display='';ot.textContent='PAUSED';os.textContent=L.n+' — '+L.t;b1.textContent='Resume';b1.onclick=resume;ov.classList.add('on')}
function resume(){state='play';ov.classList.remove('on')}
function go(i){mode==='mimic'?mLoad(i):load(i)}
const restart=()=>go(li),move=(dx,dy)=>mode==='mimic'?mMoveKey(dx,dy):moveR(dx,dy),undo=()=>mode==='mimic'?mUndo():undoR();
b2.onclick=restart;bR.onclick=restart;bM.onclick=menu;bS.onclick=switchWorld;bU.onclick=undo;
addEventListener('click',e=>{if(e.target.tagName=='BUTTON')e.target.blur()});
c.addEventListener('pointerdown',e=>{const b=c.getBoundingClientRect();if(state==='play'&&mode==='mirror'&&!scr)setAct(e.clientX-b.left<b.width/2?0:1)});
addEventListener('keydown',e=>{const k=e.key.toLowerCase();if(scr){if(k=='escape'&&scr=='levels')toMenu();return}if(mode==='mimic'&&(k==' '||k=='tab')){e.preventDefault();if(k==' ')mAct('w');return}
 const m={arrowup:[0,-1],w:[0,-1],arrowdown:[0,1],s:[0,1],arrowleft:[-1,0],a:[-1,0],arrowright:[1,0],d:[1,0]}[k];
 if(m){e.preventDefault();move(...m)}else if(k==' '||k=='tab'){e.preventDefault();switchWorld()}else if(k=='z'||k=='u'||k=='backspace'){e.preventDefault();undo()}else if(k=='r')restart();else if(k=='escape'||k=='p')menu()});
const ren=new THREE.WebGLRenderer({canvas:c,antialias:true});ren.shadowMap.enabled=true;ren.setScissorTest(true);
const cam=new THREE.PerspectiveCamera(34,1,.1,100);let cw=1,ch=1;
function size(){cw=stage.clientWidth;ch=stage.clientHeight;ren.setPixelRatio(Math.min(devicePixelRatio,2));ren.setSize(cw,ch,false)}
addEventListener('resize',size);size();
const clk=new THREE.Clock();
(function loop(){requestAnimationFrame(loop);const dt=Math.min(clk.getDelta(),.05),t=clk.elapsedTime;shake=Math.max(0,shake-dt);
 if(scr==='menu'){drawMenu(t,dt);return}if(scr==='levels')return;if(mode==='mimic'){mLoop(dt,t);return}
 if(state==='falling'){ft+=dt;if(ft>1.1)lose('YOU FELL','Step into a gap in either world and you are gone.')}
 const hw=Math.floor(cw/2),asp=hw/ch,dist=17*Math.max(1,1/asp*.95);
 cam.aspect=asp;cam.position.set(0,dist*.72,dist*.7);cam.lookAt(0,-.2,.2);cam.updateProjectionMatrix();
 const tg=[[S.pc-3,S.pr-3],[C-1-S.pc-3,S.pr-3]],k=Math.min(1,dt*14);
 W.forEach((w,i)=>{const a=w.ac;a.position.x+=(tg[i][0]-a.position.x)*Math.min(1,dt*18);a.position.z+=(tg[i][1]-a.position.z)*Math.min(1,dt*18);
  if(fall[i]){const u=Math.max(0,ft-.12);a.position.y=-u*u*14;a.rotation.z+=dt*7;a.rotation.x+=dt*4;a.scale.setScalar(Math.max(.2,1-u*.6))}
  else a.position.y=Math.abs(Math.sin(t*3))*.03;
  if(shake>0&&!fall[i])a.position.x+=Math.sin(t*90)*.05;
  w.anim.forEach((o,j)=>o.rotation.y=t*.6+j);w.gl.material.opacity=.65+Math.sin(t*3+i)*.2;w.pl.intensity=2+Math.sin(t*4)*.7;w.ring.rotation.z=t;
  w.pts.rotation.y=t*.03;w.pts.position.y=Math.sin(t*.5)*.2;
  w.crates.forEach(o=>{const q=o.userData.t;o.position.x+=(q[0]-o.position.x)*k;o.position.z+=(q[1]-o.position.z)*k});
  w.plates.forEach(o=>{const u=o.m.userData,mt=u.top.material;o.m.position.y+=((u.on?-.03:0)-o.m.position.y)*k;mt.emissiveIntensity+=((u.on?1.8:.2)-mt.emissiveIntensity)*k});
  [...w.gates,...w.doors].forEach(o=>{const u=o.m.userData,g=u.bars||u.body;g.scale.y+=((u.open?.02:1)-g.scale.y)*k;g.visible=g.scale.y>.06});
  w.keys.forEach((o,j)=>{const q=o.m;q.visible=!q.userData.got;q.rotation.y=t*2;q.position.y=.55+Math.sin(t*3+j)*.05});
  if(!fall[i]){a.userData.sh.material.opacity+=((act==i?.75:.2)-a.userData.sh.material.opacity)*k;a.userData.pl.intensity=act==i?1.4:.5}
  ren.setViewport(i*hw,0,hw,ch);ren.setScissor(i*hw,0,hw,ch);ren.render(w.s,cam)})})();

// ===== MIMIC rendering + campaign menu + navigation (added in v3; MIRROR code above is unchanged except where noted) =====
const app=$('app'),menuEl=$('menu'),lvsel=$('lvsel'),lsg=$('lsg'),lst=$('lst'),lss=$('lss'),eq=$('eq'),b3=$('b3'),b4=$('b4'),mt2=$('mt2'),cvm=$('cvm'),cvr=$('cvr');
let PG={mimic:1,mirror:1};try{const q=JSON.parse(localStorage.getItem('echobound.progress')||'{}');PG.mimic=q.mimic||1;PG.mirror=q.mirror||1}catch(e){}
const saveProg=()=>{const n=mode==='mimic'?MLV.length:LV.length;PG[mode]=Math.min(n,Math.max(PG[mode],li+2));try{localStorage.setItem('echobound.progress',JSON.stringify(PG))}catch(e){}};
const AR={u:'↑',d:'↓',l:'←',r:'→',w:'•'};
function mkEcho(s,lv){const g=figure(0x35e0d0,0x40e0ff);[0,1,2].forEach(i=>{const o=g.children[i];o.material=o.material.clone();o.material.transparent=true;o.material.opacity=.78});
 g.traverse(o=>{if(o.isMesh)o.castShadow=true});g.visible=!!lv.dl;s.add(g);return g}
let mfall=0;
function mSync(){const w=mw;
 w.crates.forEach((o,j)=>o.userData.t=[MS.cr[j][0]-3,MS.cr[j][1]-3]);
 w.plates.forEach(o=>o.m.userData.on=mOcc(MS,o.c,o.r));
 w.gates.forEach(o=>o.m.userData.open=mGate(MP,MS,o.ch));
 const lv=MP.lv;eq.innerHTML=lv.dl?'ECHO NEXT <span>'+(MS.q.length<lv.dl?'· '.repeat(lv.dl-MS.q.length):'')+MS.q.map(a=>AR[a]).join(' ')+'</span>':''}
function mLoad(i){mode='mimic';scr=null;app.className='mimic';li=i;const lv=MLV[i];MP=mParse(lv);MS=mInit(MP);hist=[];moves=0;state='play';mfall=0;ft=0;shake=0;b2.style.display='';
 L={n:'LEVEL '+(i+1),t:lv.n,mx:lv.mx};
 mw=build(MP.maps,'u',false,{cr:MP.cr,ex:lv.xp,ex2:lv.dl?lv.xe:null,fc:[0xff8a5c,0xffc247]});
 mw.echo=mkEcho(mw.s,lv);mw.ac.position.set(lv.p[0]-3,0,lv.p[1]-3);if(lv.dl)mw.echo.position.set(lv.e[0]-3,0,lv.e[1]-3);
 mt2.innerHTML=lv.dl?'Your echo repeats every move<br><b>'+lv.dl+'</b> step'+(lv.dl>1?'s':'')+' later. <kbd>Space</kbd> wait':'No echo yet.<br>Walk to the golden exit.';
 mSync();lvn.textContent=L.n;lvt.textContent=L.t;hud();ov.classList.remove('on')}
function mAct(a){if(state!=='play')return;const t=mStep(MP,MS,a);if(!t){shake=.25;return}
 hist.push(MS);MS=t;moves++;hud();mSync();
 if(t.dead){state='falling';mfall=t.dead;ft=0;shake=.5;flash();return}
 if(mWon(MP,t)){state='won';setTimeout(win,450)}else if(moves>=L.mx){state='lost';setTimeout(()=>lose('OUT OF MOVES','You used all '+L.mx+' moves.'),600)}}
const mMoveKey=(dx,dy)=>mAct(dx<0?'l':dx>0?'r':dy<0?'u':'d');
const mUndo=()=>{if(state!=='play'||!hist.length)return;MS=hist.pop();moves--;hud();mSync()};
function mLoop(dt,t){shake=Math.max(0,shake-dt);
 if(state==='falling'){ft+=dt;if(ft>1.1)lose(mfall==1?'YOU FELL':'YOUR ECHO FELL','Mind the gaps — your echo repeats your moves too.')}
 const w=mw,asp=cw/ch,dist=17*Math.max(1,1/asp*.95),k=Math.min(1,dt*14);
 cam.aspect=asp;cam.position.set(0,dist*.72,dist*.7);cam.lookAt(0,-.2,.2);cam.updateProjectionMatrix();
 const fig=(a,p,dead,ph)=>{a.position.x+=(p[0]-3-a.position.x)*Math.min(1,dt*18);a.position.z+=(p[1]-3-a.position.z)*Math.min(1,dt*18);
  if(dead){const u=Math.max(0,ft-.12);a.position.y=-u*u*14;a.rotation.z+=dt*7;a.rotation.x+=dt*4;a.scale.setScalar(Math.max(.2,1-u*.6))}
  else{a.position.y=Math.abs(Math.sin(t*3+ph))*.03;if(shake>0)a.position.x+=Math.sin(t*90)*.05}};
 fig(w.ac,MS.p,mfall==1,0);if(MS.e){fig(w.echo,MS.e,mfall==2,1.5);w.echo.children[0].material.opacity=.6+Math.sin(t*4)*.15;w.echo.userData.pl.intensity=1.2+Math.sin(t*4)*.4}
 w.ac.userData.pl.intensity=1.4;
 w.anim.forEach((o,j)=>o.rotation.y=t*.6+j);w.gl.material.opacity=.65+Math.sin(t*3)*.2;w.pl.intensity=2+Math.sin(t*4)*.7;w.ring.rotation.z=t;w.pts.rotation.y=t*.03;w.pts.position.y=Math.sin(t*.5)*.2;
 w.crates.forEach(o=>{const q=o.userData.t;o.position.x+=(q[0]-o.position.x)*k;o.position.z+=(q[1]-o.position.z)*k});
 w.plates.forEach(o=>{const u=o.m.userData,mt=u.top.material;o.m.position.y+=((u.on?-.03:0)-o.m.position.y)*k;mt.emissiveIntensity+=((u.on?1.8:.2)-mt.emissiveIntensity)*k});
 w.gates.forEach(o=>{const u=o.m.userData,g=u.bars;g.scale.y+=((u.open?.02:1)-g.scale.y)*k;g.visible=g.scale.y>.06});
 ren.setViewport(0,0,cw,ch);ren.setScissor(0,0,cw,ch);ren.render(w.s,cam)}
// ---- main menu: two live 3D previews rendered with the same engine ----
function initMenu(){P=parseLevel(LV[3]);
 const mp=mParse(MLV[5]);
 pv={m:build(mp.maps,'u',false,{cr:mp.cr,ex:MLV[5].xp,ex2:MLV[5].xe,fc:[0xff8a5c,0xffc247]}),r:[build(P.maps[0],'r',false),build(P.maps[1],'m',true)]};
 pv.m.echo=mkEcho(pv.m.s,MLV[5]);pv.m.ac.position.set(1-3,0,6-3);pv.m.echo.position.set(3-3,0,6-3);
 pv.r[0].ac.position.set(SC-3,0,SR-3);pv.r[1].ac.position.set(C-1-SC-3,0,SR-3);
 prs=[cvm,cvr].map(cv=>{const r=new THREE.WebGLRenderer({canvas:cv,antialias:true});r.setScissorTest(true);return r});
 $('pm').onclick=()=>showLevels('mimic');$('pr').onclick=()=>showLevels('mirror')}
function drawMenu(t,dt){if(!pv)return;const pc=new THREE.PerspectiveCamera(34,1,.1,100);
 const draw=(r,cv,scenes)=>{const w=cv.clientWidth,h=cv.clientHeight;if(!w||!h)return;if(cv.width!==Math.round(w*Math.min(devicePixelRatio,2))){r.setPixelRatio(Math.min(devicePixelRatio,2));r.setSize(w,h,false)}
  const n=scenes.length,hw=Math.floor(w/n);scenes.forEach((s,i)=>{const asp=hw/h;pc.aspect=asp;const d=17*Math.max(1,1/asp*.95)*.92;pc.position.set(Math.sin(t*.35)*1.6,d*.72,d*.7);pc.lookAt(0,-.2,.2);pc.updateProjectionMatrix();
   r.setViewport(i*hw,0,hw,h);r.setScissor(i*hw,0,hw,h);r.render(s.s,pc)})};
 const a=pv.m;a.anim.forEach((o,j)=>o.rotation.y=t*.6+j);a.gl.material.opacity=.65+Math.sin(t*3)*.2;a.ring.rotation.z=t;a.echo.position.y=Math.abs(Math.sin(t*3+1.5))*.03;a.ac.position.y=Math.abs(Math.sin(t*3))*.03;
 pv.r.forEach((w,i)=>{w.anim.forEach((o,j)=>o.rotation.y=t*.6+j);w.gl.material.opacity=.65+Math.sin(t*3+i)*.2;w.ring.rotation.z=t});
 draw(prs[0],cvm,[a]);draw(prs[1],cvr,pv.r)}
// ---- navigation ----
function showLevels(m){mode=m;scr='levels';state='menu';ov.classList.remove('on');menuEl.classList.remove('on');lvsel.className='on '+m;
 const mi=m==='mimic',n=mi?MLV.length:LV.length;lst.textContent=mi?'MIMIC':'MIRROR';lss.textContent=mi?'Every step leaves an echo. Seven gentle levels.':'Two worlds. Reversed paths. One escape.';
 lsg.innerHTML='';for(let i=0;i<n;i++){const b=document.createElement('button'),ok=i<PG[m];b.className='lt';b.disabled=!ok;
  b.innerHTML='<i>'+(i+1)+'</i><span>'+(mi?MLV[i].n:LV[i].t)+'</span><small>'+(ok?(i<PG[m]-1||PG[m]>=n&&false?'cleared':'ready'):'locked')+'</small>';
  b.onclick=()=>{lvsel.classList.remove('on');scr=null;(m==='mimic'?mLoad:load)(i)};lsg.appendChild(b)}}
function toLevels(){showLevels(mode==='mimic'?'mimic':'mirror')}
function toMenu(){scr='menu';state='menu';ov.classList.remove('on');lvsel.classList.remove('on');app.className='';menuEl.classList.add('on')}
$('lsb').onclick=toMenu;b3.onclick=toLevels;b4.onclick=toMenu;
initMenu();menuEl.classList.add('on');

})({Group:Ie,Mesh:Dt,MeshStandardMaterial:wn,MeshBasicMaterial:vn,BoxGeometry:ge,TorusGeometry:va,OctahedronGeometry:Cm,ConeGeometry:gr,SphereGeometry:Im,CircleGeometry:hl,PlaneGeometry:Xa,PointLight:Pr,Scene:Hs,Fog:Tr,HemisphereLight:Ml,DirectionalLight:Tl,BufferGeometry:It,Points:cl,PointsMaterial:ks,WebGLRenderer:Ut,PerspectiveCamera:ue,Clock:yg,Color:ct,Float32BufferAttribute:Tt,AdditiveBlending:vs});
