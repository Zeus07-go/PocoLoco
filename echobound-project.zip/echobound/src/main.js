import * as THREE from 'three';
import './style.css';
import {C,R,SC,SR,EC,ER,LV} from './levels.js';
const T={
 r:{bg:0x0b2a4d,fog:0x12457a,stone:[0x5d7690,0x6a86a3],wall:0x7b97b4,cr:0x5fe6ff,lan:0x59c8ff,sky:0x9fd8ff,gnd:0x1a3a66,key:0xaad4ff,pt:0x44ccff,ac:0x2fa8ff},
 m:{bg:0x1a0b33,fog:0x2e1456,stone:[0x4b3a6e,0x57447c],wall:0x5d4a8a,cr:0xffc14a,lan:0xffa030,sky:0xb890ff,gnd:0x2a1148,key:0xd7b0ff,pt:0xffb040,ac:0xffb23a}};
let L,li=0,pc,pr,moves=0,state='play',shake=0,W=[];
const rn=(a,b)=>{const x=Math.sin(a*127.1+b*311.7)*43758.5453;return x-Math.floor(x)};
const std=(c,o={})=>new THREE.MeshStandardMaterial(Object.assign({color:c,flatShading:true,roughness:.85,metalness:.05},o));
function crystal(col,s){const g=new THREE.Group(),m=new THREE.MeshStandardMaterial({color:col,emissive:col,emissiveIntensity:1.1,flatShading:true,roughness:.2});
 for(let i=0;i<3;i++){const o=new THREE.Mesh(new THREE.OctahedronGeometry(.1*s*(1-i*.2)),m);o.scale.y=2.2;o.position.set((i-1)*.1*s,.1*s*(2-i*.4),i%2*.06);o.rotation.y=i;g.add(o)}return g}
function lantern(col){const g=new THREE.Group();const b=new THREE.Mesh(new THREE.BoxGeometry(.22,.06,.22),std(0x2a2f3a));const p=new THREE.Mesh(new THREE.BoxGeometry(.04,.3,.04),std(0x2a2f3a));p.position.y=.18;
 const l=new THREE.Mesh(new THREE.BoxGeometry(.2,.22,.2),new THREE.MeshStandardMaterial({color:col,emissive:col,emissiveIntensity:1.6}));l.position.y=.42;const pl=new THREE.PointLight(col,.7,3);pl.position.y=.45;g.add(b,p,l,pl);return g}
function figure(col,glow){const g=new THREE.Group(),m=new THREE.MeshStandardMaterial({color:col,emissive:col,emissiveIntensity:.5,flatShading:true});
 const body=new THREE.Mesh(new THREE.ConeGeometry(.24,.62,7),m);body.position.y=.31;const head=new THREE.Mesh(new THREE.SphereGeometry(.15,10,8),m);head.position.y=.72;
 const hood=new THREE.Mesh(new THREE.ConeGeometry(.17,.22,7),m);hood.position.y=.88;
 const sig=new THREE.Mesh(new THREE.BoxGeometry(.09,.09,.02),new THREE.MeshBasicMaterial({color:0xffffff}));sig.position.set(0,.4,.2);sig.rotation.z=.78;
 const sh=new THREE.Mesh(new THREE.CircleGeometry(.3,16),new THREE.MeshBasicMaterial({color:glow,transparent:true,opacity:.35}));sh.rotation.x=-Math.PI/2;sh.position.y=.02;
 const pl=new THREE.PointLight(glow,1.2,3.5);pl.position.y=.9;g.add(body,head,hood,sig,sh,pl);return g}
function build(map,th,mir){
 const s=new THREE.Scene(),t=T[th];s.background=new THREE.Color(t.bg);s.fog=new THREE.Fog(t.fog,14,42);
 s.add(new THREE.HemisphereLight(t.sky,t.gnd,.9));
 const d=new THREE.DirectionalLight(t.key,.9);d.position.set(mir?-6:6,12,8);d.castShadow=true;d.shadow.mapSize.set(1024,1024);const sc=d.shadow.camera;sc.left=sc.bottom=-8;sc.right=sc.top=8;s.add(d);
 const anim=[],tx=c=>c-3,tz=r=>r-3;
 for(let r=0;r<R;r++)for(let c=0;c<C;c++){const ch=map[r][c];if(ch=='#')continue;const h=rn(c,r+(mir?9:0));
  const col=new THREE.Color(t.stone[h>.5?1:0]).offsetHSL(0,0,(h-.5)*.08);
  const tile=new THREE.Mesh(new THREE.BoxGeometry(.97,.5,.97),std(col));tile.position.set(tx(c),-.25,tz(r));tile.receiveShadow=true;s.add(tile);
  const rock=new THREE.Mesh(new THREE.ConeGeometry(.62,1.4+h*1.6,4),std(new THREE.Color(t.stone[0]).multiplyScalar(.6)));rock.rotation.set(Math.PI,Math.PI/4,0);rock.position.set(tx(c),-1.2-h*.8,tz(r));s.add(rock);
  if(ch=='W'){const hh=1+Math.floor(h*2)*.0;const w=new THREE.Mesh(new THREE.BoxGeometry(.95,1.1,.95),std(t.wall));w.position.set(tx(c),.55,tz(r));w.castShadow=w.receiveShadow=true;s.add(w);
   const cap=new THREE.Mesh(new THREE.BoxGeometry(1.02,.12,1.02),std(new THREE.Color(t.wall).multiplyScalar(1.25)));cap.position.set(tx(c),1.14,tz(r));s.add(cap);
   if(h>.82){const cr=crystal(t.cr,1.1);cr.position.set(tx(c),1.2,tz(r));s.add(cr);anim.push(cr)}}
  else if(h>.9&&!(c==(mir?C-1-SC:SC)&&r==SR)){const o=h>.95?lantern(t.lan):crystal(t.cr,1);o.position.set(tx(c)+.28,0,tz(r)+.28);s.add(o);anim.push(o)}
 }
 // far floating ruins
 for(let i=0;i<22;i++){const a=rn(i,mir?3:1)*6.28,rad=7+rn(i,5)*10,hh=1+rn(i,7)*4;const g=new THREE.Group();
  const b=new THREE.Mesh(new THREE.BoxGeometry(1+rn(i,2)*1.6,hh,1+rn(i,4)*1.6),std(t.stone[0]));const k=new THREE.Mesh(new THREE.ConeGeometry(.9,1.8,4),std(t.stone[0]));k.rotation.x=Math.PI;k.position.y=-hh/2-.9;g.add(b,k);
  g.position.set(Math.cos(a)*rad,-2-rn(i,8)*7+hh/2,Math.sin(a)*rad-4);s.add(g)}
 // exit portal
 const ec=mir?C-1-EC:EC,p=new THREE.Group(),pm=new THREE.MeshStandardMaterial({color:t.stone[1],flatShading:true});
 [-.4,.4].forEach(x=>{const pi=new THREE.Mesh(new THREE.BoxGeometry(.2,1.5,.3),pm);pi.position.set(x,.75,0);p.add(pi)});
 const top=new THREE.Mesh(new THREE.TorusGeometry(.4,.1,6,10,Math.PI),pm);top.position.y=1.5;p.add(top);
 const gl=new THREE.Mesh(new THREE.CircleGeometry(.36,24),new THREE.MeshBasicMaterial({color:t.pt,transparent:true,opacity:.85,blending:THREE.AdditiveBlending}));gl.position.set(0,.92,.02);
 const gl2=new THREE.Mesh(new THREE.PlaneGeometry(.72,1.5),gl.material);gl2.position.set(0,.75,.01);p.add(gl,gl2);
 const pl=new THREE.PointLight(t.pt,2,6);pl.position.set(0,1,.8);p.add(pl);
 const ring=new THREE.Mesh(new THREE.TorusGeometry(.42,.03,6,24),new THREE.MeshBasicMaterial({color:t.pt}));ring.rotation.x=Math.PI/2;ring.position.y=.04;p.add(ring);
 p.position.set(tx(ec),0,tz(ER));s.add(p);
 // particles
 const pg=new THREE.BufferGeometry(),pa=[];for(let i=0;i<140;i++)pa.push((Math.random()-.5)*14,Math.random()*7-1,(Math.random()-.5)*14);
 pg.setAttribute('position',new THREE.Float32BufferAttribute(pa,3));const pts=new THREE.Points(pg,new THREE.PointsMaterial({color:t.pt,size:.07,transparent:true,opacity:.8}));s.add(pts);
 const ac=figure(mir?0xffc247:0x3f9bff,mir?0xffa830:0x44aaff);ac.traverse(o=>{if(o.isMesh)o.castShadow=true});s.add(ac);
 return {s,anim,ac,gl,pl,ring,pts,ex:p};
}
function load(i){li=i;L=LV[i];moves=0;state='play';pc=SC;pr=SR;
 W=[build(L.R,'r',false),build(L.M,'m',true)];
 W[0].ac.position.set(pc-3,0,pr-3);W[1].ac.position.set(C-1-pc-3,0,pr-3);
 document.getElementById('lvn').textContent=L.n;document.getElementById('lvt').textContent=L.t;
 document.getElementById('mv').textContent=0;document.getElementById('ov').classList.remove('on')}
const ok=(m,c,r)=>c>=0&&c<C&&r>=0&&r<R&&m[r][c]=='.';
function move(dx,dy){if(state!=='play')return;const nc=pc+dx,nr=pr+dy,sc=C-1-nc;
 if(ok(L.R,nc,nr)&&ok(L.M,sc,nr)){pc=nc;pr=nr;moves++;document.getElementById('mv').textContent=moves;
  if(pc==EC&&pr==ER&&C-1-pc==C-1-EC){state='won';setTimeout(win,450)}}else shake=.25}
function win(){const last=li==LV.length-1;document.getElementById('ot').textContent=last?'ALL WORLDS ESCAPED':'LEVEL COMPLETE';
 document.getElementById('os').textContent='Both exits reached in '+moves+' moves.';b1.textContent=last?'Play Again':'Next Level';b1.onclick=()=>load(last?0:li+1);ov.classList.add('on')}
function menu(){if(state==='won')return;if(state==='paused'){resume();return}state='paused';ot.textContent='PAUSED';os.textContent=L.n+' — '+L.t;b1.textContent='Resume';b1.onclick=resume;ov.classList.add('on')}
function resume(){state='play';ov.classList.remove('on')}
const restart=()=>load(li);
b2.onclick=restart;bR.onclick=restart;bM.onclick=menu;
addEventListener('keydown',e=>{const k=e.key.toLowerCase();
 const m={arrowup:[0,-1],w:[0,-1],arrowdown:[0,1],s:[0,1],arrowleft:[-1,0],a:[-1,0],arrowright:[1,0],d:[1,0]}[k];
 if(m){e.preventDefault();move(...m)}else if(k=='r')restart();else if(k=='escape'||k=='p')menu()});
const ren=new THREE.WebGLRenderer({canvas:c,antialias:true});ren.shadowMap.enabled=true;ren.setScissorTest(true);
const cam=new THREE.PerspectiveCamera(34,1,.1,100);let cw=1,ch=1;
function size(){const st=document.getElementById('stage');cw=st.clientWidth;ch=st.clientHeight;ren.setPixelRatio(Math.min(devicePixelRatio,2));ren.setSize(cw,ch,false)}
addEventListener('resize',size);size();load(1);
const clk=new THREE.Clock();
(function loop(){requestAnimationFrame(loop);const dt=Math.min(clk.getDelta(),.05),t=clk.elapsedTime;shake=Math.max(0,shake-dt);
 const hw=Math.floor(cw/2),asp=hw/ch,dist=17*Math.max(1,1/asp*.95);
 cam.aspect=asp;cam.position.set(0,dist*.72,dist*.7);cam.lookAt(0,-.2,.2);cam.updateProjectionMatrix();
 const tg=[[pc-3,pr-3],[C-1-pc-3,pr-3]];
 W.forEach((w,i)=>{const a=w.ac;a.position.x+=(tg[i][0]-a.position.x)*Math.min(1,dt*18);a.position.z+=(tg[i][1]-a.position.z)*Math.min(1,dt*18);
  a.position.y=Math.abs(Math.sin(t*3))*.03;if(shake>0)a.position.x+=Math.sin(t*90)*.05;
  w.anim.forEach((o,j)=>o.rotation.y=t*.6+j);w.gl.material.opacity=.65+Math.sin(t*3+i)*.2;w.pl.intensity=2+Math.sin(t*4)*.7;w.ring.rotation.z=t;
  w.pts.rotation.y=t*.03;w.pts.position.y=Math.sin(t*.5)*.2;
  ren.setViewport(i*hw,0,hw,ch);ren.setScissor(i*hw,0,hw,ch);ren.render(w.s,cam)})})();
