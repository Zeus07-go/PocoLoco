# ECHOBOUND
npm install
npm run dev      # open the printed local URL
npm run build    # production build in /dist

Files: index.html (HUD markup), src/style.css (HUD styling), src/levels.js (level maps), src/main.js (scenes, gameplay, loop).
