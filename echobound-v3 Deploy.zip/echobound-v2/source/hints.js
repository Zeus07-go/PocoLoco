
// ===== Hints: 3 per level (not refilled by restart). Solves from the CURRENT position and shows the next 3 moves. =====
const HR={};let hintTm=null;
function rSolve(P,s0,cap){const D=[[0,-1,'u'],[0,1,'d'],[-1,0,'l'],[1,0,'r']],key=s=>[s.pc,s.pr,s.cr.map(a=>a.map(p=>p.join(',')).sort().join(';')).join('|'),[...s.got].sort()].join('#');
 let cur=[[s0,[]]];const seen=new Set([key(s0)]);
 for(let d=0;d<=cap;d++){const nx=[];for(const [s,h] of cur){if(won(s))return h;for(const [dx,dy,c] of D){const t=step(P,s,dx,dy,false);if(t){const k=key(t);if(!seen.has(k)){seen.add(k);nx.push([t,[...h,c]])}}}}cur=nx;if(!cur.length)return null}return null}
function showHint(msg,ok){const h=$('hint');h.textContent=msg;h.className='ov on'+(ok?'':' no');clearTimeout(hintTm);hintTm=setTimeout(()=>h.classList.remove('on'),7000)}
function hintLabel(){const k=mode+li;$('bH').textContent='💡 Hint (H) · '+(HR[k]===undefined?3:HR[k]);$('hint').classList.remove('on')}
function hint(){if(state!=='play'||scr)return;const k=mode+li;if(HR[k]===undefined)HR[k]=3;
 const rem=L.mx-moves;let path;
 if(mode==='mimic'){const r=mSolve(MP,rem,MS);path=r&&r.path.split('')}else path=rSolve(P,S,rem);
 if(!path){showHint('Can’t be finished in the moves left — try Undo (Z) or Restart (R).',false);return}
 if(!path.length)return;
 if(HR[k]<=0){showHint('No hints left on this level.',false);return}
 HR[k]--;AU.hint();
 const flip=mode==='mirror'&&act==1,txt=path.slice(0,3).map(a=>a=='w'?'wait (Space)':AR[flip&&a=='l'?'r':flip&&a=='r'?'l':a]).join('   ');
 showHint('Next:  '+txt,true);hintLabel();$('hint').classList.add('on');showHint('Next:  '+txt+'     ('+HR[k]+' left)',true)}
$('bH').onclick=hint;
