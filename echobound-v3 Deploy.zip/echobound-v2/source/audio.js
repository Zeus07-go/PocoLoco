// ===== Procedural audio (WebAudio, no files): music per screen + sound effects =====
const AU=(()=>{let ctx,mg,mus,sx,nb,muted=false,track=null,nxt=0,st=0,tm=null,fs=0;
 try{muted=localStorage.getItem('echobound.mute')==='1'}catch(e){}
 const hs=n=>{const x=Math.sin(n*12.9898)*43758.5453;return x-Math.floor(x)},mf=m=>440*Math.pow(2,(m-69)/12);
 const lab=()=>document.querySelectorAll('.sb').forEach(b=>b.textContent=muted?'♪ Sound: Off':'♪ Sound: On');
 const log=n=>{if(window.__sfxLog)window.__sfxLog.push(n)};
 const tone=(bus,f,t,d,type,v,att=.01,f2)=>{const o=ctx.createOscillator(),g=ctx.createGain();o.type=type;o.frequency.setValueAtTime(f,t);if(f2)o.frequency.exponentialRampToValueAtTime(f2,t+d);
  g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(v,t+att);g.gain.exponentialRampToValueAtTime(.0001,t+d);o.connect(g);g.connect(bus);o.start(t);o.stop(t+d+.05)};
 const noise=(t,d,v,fq)=>{const s=ctx.createBufferSource(),f=ctx.createBiquadFilter(),g=ctx.createGain();s.buffer=nb;f.type='bandpass';f.frequency.value=fq;
  g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.0001,t+d);s.connect(f);f.connect(g);g.connect(sx);s.start(t);s.stop(t+d+.05)};
 const TR={mimic:{bpm:100,ch:[[60,64,67],[57,60,64],[53,57,60],[55,59,62]],oct:0,pad:0,mp:.55,bs:[0,4],arp:'triangle'},
  menu:{bpm:80,ch:[[60,64,67],[57,60,64],[53,57,60],[55,59,62]],oct:0,pad:1,mp:.7,bs:[0],arp:'sine'},
  mirror:{bpm:72,ch:[[57,60,64],[53,57,60],[50,53,57],[52,56,59]],oct:-12,pad:1,mp:.8,bs:[0],arp:'triangle'}};
 const PENT=[72,74,76,79,81,84],IDX=[0,1,2,1,0,1,2,1];
 const play=(tr,s,t,sd)=>{const bar=Math.floor(s/8)%4,i=s%8,ch=tr.ch[bar];
  tone(mus,mf(ch[IDX[i]]+tr.oct),t,sd*3.2,tr.arp,.32,.01);
  if(tr.bs.includes(i))tone(mus,mf(ch[0]-24),t,sd*(tr.pad?7:3.5),'sine',.6,.02);
  if(tr.pad&&i==0)ch.forEach(n=>tone(mus,mf(n+tr.oct),t,sd*8,'sine',.1,sd*3));
  if(hs(s*7+tr.bpm)>tr.mp&&i%2==0){const n=PENT[Math.floor(hs(s*3+1)*6)]+(tr.oct?-12:0);tone(mus,mf(n),t,sd*4,'sine',.28,.005);tone(mus,mf(n),t+sd*1.5,sd*3,'sine',.1,.005)} // the melody echoes itself
 };
 const tick=()=>{const tr=TR[track];if(!tr||!ctx)return;const sd=60/tr.bpm/2;while(nxt<ctx.currentTime+.5){play(tr,st,nxt,sd);nxt+=sd;st++}};
 const start=()=>{clearInterval(tm);st=0;nxt=ctx.currentTime+.08;tm=setInterval(tick,120);tick()};
 const A={
  init(){if(ctx){if(ctx.state==='suspended')ctx.resume();return}
   const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return;ctx=new AC();mg=ctx.createGain();mg.gain.value=muted?0:1;mg.connect(ctx.destination);
   mus=ctx.createGain();mus.gain.value=.2;mus.connect(mg);sx=ctx.createGain();sx.gain.value=.55;sx.connect(mg);
   nb=ctx.createBuffer(1,ctx.sampleRate,ctx.sampleRate);const d=nb.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;
   if(track)start()},
  music(n){if(n===track)return;track=n;if(ctx)start()},
  mute(){muted=!muted;try{localStorage.setItem('echobound.mute',muted?'1':'0')}catch(e){}if(ctx)mg.gain.setTargetAtTime(muted?0:1,ctx.currentTime,.05);lab();A.init()},
  step(){log('step');if(!ctx||muted)return;const t=ctx.currentTime;fs++;tone(sx,(fs%2?135:165),t,.09,'sine',.9,.002,60);noise(t,.05,.3,1800)},
  bump(){log('bump');if(!ctx||muted)return;tone(sx,90,ctx.currentTime,.08,'sine',.5,.002,50)},
  fall(){log('fall');if(!ctx||muted)return;const t=ctx.currentTime;tone(sx,720,t,1,'sine',.45,.01,50);noise(t,.9,.22,500);tone(sx,60,t+.85,.35,'sine',.9,.005,35)},
  oom(){log('oom');if(!ctx||muted)return;const t=ctx.currentTime;[[392,0,.22],[370,.24,.22],[349,.48,.22],[330,.72,.8]].forEach(([f,o,d])=>tone(sx,f,t+o,d,'triangle',.4,.02,f*.96))},
  hint(){log('hint');if(!ctx||muted)return;const t=ctx.currentTime;tone(sx,880,t,.3,'sine',.3,.005);tone(sx,1318,t+.1,.4,'sine',.25,.005)},
  retry(){log('retry');if(!ctx||muted)return;const t=ctx.currentTime;tone(sx,220,t,.35,'triangle',.35,.01,880);noise(t,.3,.12,2500);tone(sx,659,t+.28,.14,'triangle',.3,.005);tone(sx,988,t+.38,.25,'triangle',.3,.005)}
 };
 lab();document.querySelectorAll('.sb').forEach(b=>b.onclick=A.mute);
 ['pointerdown','keydown'].forEach(ev=>addEventListener(ev,()=>A.init(),true));
 return A})();
