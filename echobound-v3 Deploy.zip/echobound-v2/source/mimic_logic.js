// MIMIC rules (pure). One world, one hero, one echo that repeats the hero's moves D actions later.
// Tiles: . floor  W wall  # gap  X crate  a b plates  A B gates (same world; open while a plate is occupied by hero, echo or crate)
// Actions: u d l r move, w wait (recorded too, so the echo can catch up).
const MDIR={u:[0,-1],d:[0,1],l:[-1,0],r:[1,0],w:[0,0]};
const MC=7,MR=7;
const mIn=(c,r)=>c>=0&&c<MC&&r>=0&&r<MR;
function mParse(lv){const maps=lv.M.map(row=>[...row]),cr=[],pl={};
  maps.forEach((row,r)=>row.forEach((ch,c)=>{if(ch==='X'){cr.push([c,r]);row[c]='.'}else if('ab'.includes(ch))(pl[ch]=pl[ch]||[]).push([c,r])}));
  return {maps,cr,pl,lv}}
const mInit=P=>({p:[...P.lv.p],e:P.lv.dl?[...P.lv.e]:null,q:[],cr:P.cr.map(a=>[...a]),dead:0});
const mOcc=(s,c,r)=>(s.p[0]===c&&s.p[1]===r)||(s.e&&s.e[0]===c&&s.e[1]===r)||s.cr.some(q=>q[0]===c&&q[1]===r);
const mGate=(P,s,ch)=>(P.pl[ch.toLowerCase()]||[]).some(([c,r])=>mOcc(s,c,r));
// blocked for walking (gaps are NOT blocked: stepping in means falling)
function mBlock(P,s,c,r){if(!mIn(c,r))return true;const ch=P.maps[r][c];return ch==='W'||('AB'.includes(ch)&&!mGate(P,s,ch))}
// move one actor (0 hero, 1 echo) in state n (mutates n). Returns false if blocked.
function mMove(P,n,who,a){const [dx,dy]=MDIR[a],f=who?n.e:n.p,o=who?n.p:n.e,t=[f[0]+dx,f[1]+dy];
  if(a==='w')return true;
  if(mBlock(P,n,t[0],t[1])||(o&&o[0]===t[0]&&o[1]===t[1]))return false;
  const i=n.cr.findIndex(q=>q[0]===t[0]&&q[1]===t[1]);
  if(i>=0){const u=[t[0]+dx,t[1]+dy];
    if(mBlock(P,n,u[0],u[1])||P.maps[u[1]]&&P.maps[u[1]][u[0]]==='#'||n.cr.some(q=>q[0]===u[0]&&q[1]===u[1])||(o&&o[0]===u[0]&&o[1]===u[1])||(f[0]===u[0]&&f[1]===u[1]))return false;
    n.cr[i]=u}
  f[0]=t[0];f[1]=t[1];if(P.maps[t[1]][t[0]]==='#')n.dead=who+1;return true}
function mStep(P,s,a){if(s.dead)return null;
  const n={p:[...s.p],e:s.e&&[...s.e],q:[...s.q],cr:s.cr.map(q=>[...q]),dead:0};
  if(a!=='w'&&!mMove(P,n,0,a))return null;
  if(n.e){n.q.push(a);if(n.q.length>P.lv.dl&&!n.dead){const m=n.q.shift();mMove(P,n,1,m)}}
  if(!n.dead){ // settled state: nothing may stand in a closed gate
    const bad=(c,r)=>'AB'.includes(P.maps[r][c])&&!mGate(P,n,P.maps[r][c]);
    if(bad(n.p[0],n.p[1])||(n.e&&bad(n.e[0],n.e[1]))||n.cr.some(q=>bad(q[0],q[1])))return null}
  return n}
const mWon=(P,s)=>!s.dead&&s.p[0]===P.lv.xp[0]&&s.p[1]===P.lv.xp[1]&&(!P.lv.dl||(s.e[0]===P.lv.xe[0]&&s.e[1]===P.lv.xe[1]));
const mKey=s=>[s.p,s.e,s.q.join(''),s.cr.map(q=>q.join()).sort().join(';')].join('|');
// BFS: shortest solution length, or -1
function mSolve(P,cap=60,from){const s0=from||mInit(P);let cur=[[s0,[]]],seen=new Set([mKey(s0)]);
  for(let d=0;d<=cap;d++){const nx=[];for(const [s,h] of cur){if(mWon(P,s))return {n:d,path:h.join('')};
    for(const a of 'udlrw'){const t=mStep(P,s,a);if(t&&!t.dead||t&&t.dead){if(t.dead)continue;const k=mKey(t);if(!seen.has(k)){seen.add(k);nx.push([t,[...h,a]])}}}}
    cur=nx;if(!cur.length)return null}return null}
const MLV=[
{n:'SUNLIT GARDEN',mx:16,dl:0,p:[1,6],xp:[5,0],M:['.......','.......','..WW...','.......','.......','.......','.......']},
{n:'FOLLOW MY LIGHT',mx:15,dl:1,p:[1,6],e:[5,6],xp:[1,0],xe:[5,0],M:['.......','.......','.W...W.','.......','.......','.......','.......']},
{n:'TWIN PATHS',mx:15,dl:2,p:[0,6],e:[6,6],xp:[0,0],xe:[6,0],M:['.......','..W.W..','.......','W..W...','.......','.W...W.','.......']},
{n:'THE GENTLE BRIDGE',mx:14,dl:2,p:[1,6],e:[5,6],xp:[1,0],xe:[5,0],M:['.......','..#.#..','.......','#.###.#','.......','.......','.......']},
{n:'LITTLE HELPERS',mx:16,dl:2,p:[1,6],e:[5,6],xp:[1,0],xe:[5,0],M:['.......','.....W.','.......','.......','.....X.','.......','.......']},
{n:'THE SUN GATE',mx:19,dl:2,p:[1,6],e:[3,6],xp:[1,0],xe:[5,0],M:['.......','.......','WW.AW.W','..X....','...a...','.......','.......']},
{n:'TOGETHER HOME',mx:27,dl:2,p:[1,6],e:[3,6],xp:[1,0],xe:[5,0],M:['.......','..#.#..','WW.AW.W','..X....','...a...','.#...#.','.......']}];
