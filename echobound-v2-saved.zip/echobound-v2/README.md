# ECHOBOUND v2 (saved milestone)
ECHOBOUND_Two_Worlds_One_Escape.html  - the playable game (single file, three.js bundled, works offline)
source/game_iife.js                   - complete readable game code (levels, rules, rendering, input) as embedded in the HTML
source/levels.js, logic.js, main.js   - the same code split by role (levels.js here lacks the mx move limits; game_iife.js has them)
source/build_game.py, build_html.py   - rebuild scripts (assemble game_iife.js, then splice it into the uploaded HTML)
tests/                                - rules unit tests, level solver, headless smoke test

Features: mirrored crates, plates->gates and keys->doors across worlds, world switching (Space/Tab/click), undo (Z),
move limits, gap falls, 7 levels.
